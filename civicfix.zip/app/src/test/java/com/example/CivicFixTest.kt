package com.example

import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.model.haversineDistanceMeters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CivicFixTest {

    @Test
    fun `haversine distance calculates accurate meters between close points`() {
        // Points ~111 meters apart in latitude (0.001 deg is ~111m)
        val lat1 = 37.7749
        val lon1 = -122.4194
        val lat2 = 37.7759
        val lon2 = -122.4194

        val distance = haversineDistanceMeters(lat1, lon1, lat2, lon2)
        assertTrue("Distance should be around 111m: $distance", distance in 100.0..125.0)
    }

    @Test
    fun `issue categories mapping resolves correctly`() {
        val category = IssueCategory.fromId("pothole_roads")
        assertEquals(IssueCategory.POTHOLE_ROADS, category)
        assertEquals("Roads & Potholes", category.title)
    }

    @Test
    fun `status progression steps are ordered`() {
        assertEquals(0, IssueStatus.SUBMITTED.stepIndex)
        assertEquals(1, IssueStatus.UNDER_REVIEW.stepIndex)
        assertEquals(2, IssueStatus.ASSIGNED.stepIndex)
        assertEquals(3, IssueStatus.IN_PROGRESS.stepIndex)
        assertEquals(4, IssueStatus.RESOLVED.stepIndex)
        assertEquals(5, IssueStatus.CLOSED.stepIndex)
    }

    @Test
    fun `priority colors and labels are defined`() {
        assertEquals("Critical", IssuePriority.CRITICAL.label)
        assertEquals("High", IssuePriority.HIGH.label)
        assertEquals("Medium", IssuePriority.MEDIUM.label)
        assertEquals("Low", IssuePriority.LOW.label)
    }

    @Test
    fun `camera evidence filename contains prefix and jpg extension`() {
        val sampleName = "civic_issue_20260911_120000.jpg"
        assertTrue(sampleName.startsWith("civic_issue"))
        assertTrue(sampleName.endsWith(".jpg"))
    }
}
