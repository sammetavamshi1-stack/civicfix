package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDamage
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.PriorityCritical
import com.example.ui.theme.PriorityHigh
import com.example.ui.theme.PriorityLow
import com.example.ui.theme.PriorityMedium
import com.example.ui.theme.StatusAssigned
import com.example.ui.theme.StatusClosed
import com.example.ui.theme.StatusInProgress
import com.example.ui.theme.StatusResolved
import com.example.ui.theme.StatusSubmitted
import com.example.ui.theme.StatusUnderReview
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class UserRole(val label: String) {
    CITIZEN("Citizen"),
    ADMIN("Municipal Admin")
}

data class UserSession(
    val id: String = "citizen_001",
    val name: String = "Alex Chen",
    val email: String = "alex.chen@citycivic.org",
    val phone: String = "+1 (555) 349-8812",
    val role: UserRole = UserRole.CITIZEN,
    val department: String? = null,
    val isAnonymousDefault: Boolean = false
)

enum class IssueCategory(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val defaultDepartment: String
) {
    POTHOLE_ROADS(
        "pothole_roads",
        "Roads & Potholes",
        Icons.Default.Build,
        "Public Works Department (PWD)"
    ),
    GARBAGE_SANITATION(
        "garbage_sanitation",
        "Sanitation & Garbage",
        Icons.Default.CleaningServices,
        "Waste Management Dept"
    ),
    STREET_LIGHTING(
        "street_lighting",
        "Street Lighting",
        Icons.Default.Lightbulb,
        "Municipal Electricity Board"
    ),
    WATER_SEWAGE(
        "water_sewage",
        "Water & Drainage",
        Icons.Default.WaterDamage,
        "Water Supply & Sewerage Board"
    ),
    TRAFFIC_SIGNALS(
        "traffic_signals",
        "Traffic & Signals",
        Icons.Default.Traffic,
        "Traffic Engineering Dept"
    ),
    PARKS_TREES(
        "parks_trees",
        "Parks & Fallen Trees",
        Icons.Default.Park,
        "Parks & Greenery Dept"
    ),
    PUBLIC_HAZARDS(
        "public_hazards",
        "Public Safety Hazard",
        Icons.Default.Warning,
        "Disaster Management Dept"
    );

    companion object {
        fun fromId(id: String): IssueCategory =
            entries.find { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) }
                ?: POTHOLE_ROADS
    }
}

enum class IssueStatus(val label: String, val color: Color, val stepIndex: Int) {
    SUBMITTED("Submitted", StatusSubmitted, 0),
    UNDER_REVIEW("Under Review", StatusUnderReview, 1),
    ASSIGNED("Assigned", StatusAssigned, 2),
    IN_PROGRESS("In Progress", StatusInProgress, 3),
    RESOLVED("Resolved", StatusResolved, 4),
    CLOSED("Closed / Verified", StatusClosed, 5);

    companion object {
        fun fromName(name: String): IssueStatus =
            entries.find { it.name.equals(name, ignoreCase = true) } ?: SUBMITTED
    }
}

enum class IssuePriority(val label: String, val color: Color) {
    LOW("Low", PriorityLow),
    MEDIUM("Medium", PriorityMedium),
    HIGH("High", PriorityHigh),
    CRITICAL("Critical", PriorityCritical);

    companion object {
        fun fromName(name: String): IssuePriority =
            entries.find { it.name.equals(name, ignoreCase = true) } ?: MEDIUM
    }
}

val MunicipalDepartments = listOf(
    "Public Works Department (PWD)",
    "Waste Management Dept",
    "Municipal Electricity Board",
    "Water Supply & Sewerage Board",
    "Traffic Engineering Dept",
    "Parks & Greenery Dept",
    "Disaster Management Dept"
)

val DepartmentOfficers = mapOf(
    "Public Works Department (PWD)" to listOf("Officer Marcus Vance", "Engineer Sarah Kim"),
    "Waste Management Dept" to listOf("Supervisor Dave Miller", "Lead Tech Rosa Diaz"),
    "Municipal Electricity Board" to listOf("Inspector Jordan Hayes", "Tech Liam Patel"),
    "Water Supply & Sewerage Board" to listOf("Chief Engineer Elena Rostova", "Tech Alan Bell"),
    "Traffic Engineering Dept" to listOf("Officer Kevin Ortiz", "Signal Tech Chloe Martin"),
    "Parks & Greenery Dept" to listOf("Ranger Tom Wood", "Arborist Maya Lin"),
    "Disaster Management Dept" to listOf("Commander Ray Sterling", "Officer Jack Lee")
)

/**
 * Calculates distance between two GPS coordinates in meters using the Haversine formula.
 */
fun haversineDistanceMeters(
    lat1: Double,
    lon1: Double,
    lat2: Double,
    lon2: Double
): Double {
    val r = 6371000.0 // Earth radius in meters
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return r * c
}
