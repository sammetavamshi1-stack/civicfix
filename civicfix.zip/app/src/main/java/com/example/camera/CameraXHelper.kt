package com.example.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor

/**
 * CameraX utility helper class for managing camera lifecycle, preview binding,
 * lens switching, flash modes, and evidence photo capture for civic reports.
 */
class CameraXHelper {

    companion object {
        private const val TAG = "CameraXHelper"
        private const val FILENAME_FORMAT = "civic_issue_yyyyMMdd_HHmmss"

        /**
         * Checks if the app has the CAMERA runtime permission granted.
         */
        fun hasCameraPermission(context: Context): Boolean {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        }

        /**
         * Creates an evidence photo file stored in the app's internal cache directory.
         */
        fun createEvidencePhotoFile(context: Context): File {
            val mediaDir = File(context.cacheDir, "civic_evidence").apply { mkdirs() }
            val timeStamp = SimpleDateFormat(FILENAME_FORMAT, Locale.US).format(Date())
            return File(mediaDir, "${timeStamp}.jpg")
        }
    }

    private var cameraProvider: ProcessCameraProvider? = null
    private var currentCamera: Camera? = null
    var imageCapture: ImageCapture? = null
        private set

    /**
     * Initializes CameraX and binds preview and capture use cases to the provided LifecycleOwner and PreviewView.
     */
    fun startCamera(
        context: Context,
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        lensFacing: Int = CameraSelector.LENS_FACING_BACK,
        flashMode: Int = ImageCapture.FLASH_MODE_AUTO,
        onCameraBound: ((Camera) -> Unit)? = null,
        onError: ((Exception) -> Unit)? = null
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                // Build Preview use case
                val preview = Preview.Builder()
                    .build()
                    .also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }

                // Build ImageCapture use case
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(flashMode)
                    .build()
                imageCapture = capture

                // Select camera based on lens facing
                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                // Unbind previous use cases before rebinding
                provider.unbindAll()

                // Bind use cases to lifecycle
                val camera = provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    capture
                )
                currentCamera = camera
                onCameraBound?.invoke(camera)
                Log.d(TAG, "CameraX successfully bound to lifecycle")
            } catch (exc: Exception) {
                Log.e(TAG, "CameraX initialization failed", exc)
                onError?.invoke(exc)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    /**
     * Updates the flash mode on the active ImageCapture instance.
     */
    fun setFlashMode(flashMode: Int) {
        imageCapture?.flashMode = flashMode
    }

    /**
     * Captures a high-resolution photo and saves it to the target output file.
     *
     * @param context Android context
     * @param outputFile Target file where photo will be saved
     * @param executor Optional executor (defaults to main thread executor)
     * @param onPhotoSaved Callback invoked upon successful capture with saved File and its Uri
     * @param onError Callback invoked if capture fails
     */
    fun takePhoto(
        context: Context,
        outputFile: File = createEvidencePhotoFile(context),
        executor: Executor = ContextCompat.getMainExecutor(context),
        onPhotoSaved: (file: File, uri: Uri) -> Unit,
        onError: (ImageCaptureException) -> Unit
    ) {
        val capture = imageCapture
        if (capture == null) {
            Log.e(TAG, "ImageCapture is not initialized yet")
            onError(ImageCaptureException(ImageCapture.ERROR_CAMERA_CLOSED, "ImageCapture not initialized", null))
            return
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(outputFile).build()

        capture.takePicture(
            outputOptions,
            executor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val savedUri = outputFileResults.savedUri ?: Uri.fromFile(outputFile)
                    Log.d(TAG, "Civic evidence photo saved successfully: ${outputFile.absolutePath}")
                    onPhotoSaved(outputFile, savedUri)
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "Civic photo capture failed: ${exception.message}", exception)
                    onError(exception)
                }
            }
        )
    }

    /**
     * Unbinds all use cases and releases camera hardware resources.
     */
    fun release() {
        try {
            cameraProvider?.unbindAll()
            currentCamera = null
            imageCapture = null
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing CameraX", e)
        }
    }
}
