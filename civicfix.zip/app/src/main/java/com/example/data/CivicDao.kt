package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CivicIssueDao {
    @Query("SELECT * FROM civic_issues ORDER BY createdAt DESC")
    fun getAllIssues(): Flow<List<CivicIssueEntity>>

    @Query("SELECT * FROM civic_issues WHERE citizenId = :citizenId ORDER BY createdAt DESC")
    fun getCitizenIssues(citizenId: String): Flow<List<CivicIssueEntity>>

    @Query("SELECT * FROM civic_issues WHERE id = :id")
    suspend fun getIssueById(id: String): CivicIssueEntity?

    @Query("SELECT * FROM civic_issues WHERE id = :id")
    fun getIssueFlow(id: String): Flow<CivicIssueEntity?>

    @Query("SELECT * FROM civic_issues")
    suspend fun getAllIssuesList(): List<CivicIssueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssue(issue: CivicIssueEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssues(issues: List<CivicIssueEntity>)

    @Update
    suspend fun updateIssue(issue: CivicIssueEntity)

    @Query("UPDATE civic_issues SET upvotes = upvotes + 1 WHERE id = :id")
    suspend fun upvoteIssue(id: String)

    @Query("UPDATE civic_issues SET isSynced = 1 WHERE isSynced = 0")
    suspend fun markAllSynced()

    @Query("DELETE FROM civic_issues WHERE id = :id")
    suspend fun deleteIssue(id: String)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs WHERE issueId = :issueId ORDER BY timestamp ASC")
    fun getLogsForIssue(issueId: String): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<AuditLogEntity>)
}

@Dao
interface CivicNotificationDao {
    @Query("SELECT * FROM civic_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<CivicNotificationEntity>>

    @Query("SELECT COUNT(*) FROM civic_notifications WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: CivicNotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<CivicNotificationEntity>)

    @Query("UPDATE civic_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE civic_notifications SET isRead = 1")
    suspend fun markAllAsRead()
}
