package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "civic_issues")
data class CivicIssueEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val status: String,
    val priority: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val photoUri: String? = null,
    val resolutionPhotoUri: String? = null,
    val citizenId: String = "citizen_001",
    val citizenName: String = "Alex Chen",
    val isAnonymous: Boolean = false,
    val assignedDepartment: String? = null,
    val assignedOfficer: String? = null,
    val adminRemarks: String? = null,
    val upvotes: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val isSynced: Boolean = true,
    val duplicateOfId: String? = null
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey
    val id: String,
    val issueId: String,
    val action: String,
    val actor: String,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String? = null
)

@Entity(tableName = "civic_notifications")
data class CivicNotificationEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val message: String,
    val issueId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val type: String = "STATUS"
)
