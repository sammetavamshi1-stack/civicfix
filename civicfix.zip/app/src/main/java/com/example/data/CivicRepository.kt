package com.example.data

import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.model.haversineDistanceMeters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.UUID

class CivicRepository(private val database: CivicFixDatabase) {

    private val issueDao = database.issueDao()
    private val auditLogDao = database.auditLogDao()
    private val notificationDao = database.notificationDao()

    val allIssues: Flow<List<CivicIssueEntity>> = issueDao.getAllIssues()
    val allNotifications: Flow<List<CivicNotificationEntity>> = notificationDao.getAllNotifications()
    val unreadNotificationCount: Flow<Int> = notificationDao.getUnreadCount()

    fun getIssueFlow(id: String): Flow<CivicIssueEntity?> = issueDao.getIssueFlow(id)

    fun getAuditLogsForIssue(issueId: String): Flow<List<AuditLogEntity>> =
        auditLogDao.getLogsForIssue(issueId)

    suspend fun getIssueById(id: String): CivicIssueEntity? = issueDao.getIssueById(id)

    suspend fun upvoteIssue(id: String) {
        issueDao.upvoteIssue(id)
    }

    suspend fun markNotificationRead(id: String) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead() {
        notificationDao.markAllAsRead()
    }

    /**
     * Checks for issues within [radiusMeters] having the same [category].
     */
    suspend fun findDuplicates(
        lat: Double,
        lon: Double,
        category: String,
        radiusMeters: Double = 350.0
    ): List<CivicIssueEntity> = withContext(Dispatchers.IO) {
        val all = issueDao.getAllIssuesList()
        all.filter { issue ->
            issue.category.equals(category, ignoreCase = true) &&
                    haversineDistanceMeters(lat, lon, issue.latitude, issue.longitude) <= radiusMeters
        }
    }

    suspend fun reportIssue(
        title: String,
        description: String,
        category: IssueCategory,
        priority: IssuePriority,
        latitude: Double,
        longitude: Double,
        address: String,
        photoUri: String?,
        citizenId: String,
        citizenName: String,
        isAnonymous: Boolean,
        isLowBandwidthMode: Boolean
    ): CivicIssueEntity = withContext(Dispatchers.IO) {
        val issueNum = (1040..9999).random()
        val issueId = "CF-$issueNum"
        val now = System.currentTimeMillis()

        val newIssue = CivicIssueEntity(
            id = issueId,
            title = title,
            description = description,
            category = category.id,
            status = IssueStatus.SUBMITTED.name,
            priority = priority.name,
            latitude = latitude,
            longitude = longitude,
            address = address,
            photoUri = photoUri,
            citizenId = citizenId,
            citizenName = if (isAnonymous) "Anonymous Citizen" else citizenName,
            isAnonymous = isAnonymous,
            assignedDepartment = category.defaultDepartment,
            upvotes = 1,
            createdAt = now,
            updatedAt = now,
            isSynced = !isLowBandwidthMode
        )

        issueDao.insertIssue(newIssue)

        // Log audit trail
        auditLogDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                issueId = issueId,
                action = "Complaint Lodged",
                actor = if (isAnonymous) "Anonymous Citizen" else citizenName,
                timestamp = now,
                notes = "Initial complaint submitted from mobile application."
            )
        )

        // Send confirmation notification
        notificationDao.insertNotification(
            CivicNotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Complaint Registered #$issueId",
                message = "Your report '$title' has been received by ${category.defaultDepartment}. Tracking is now active.",
                issueId = issueId,
                timestamp = now,
                isRead = false,
                type = "NEW_REPORT"
            )
        )

        newIssue
    }

    suspend fun updateIssueStatus(
        issueId: String,
        newStatus: IssueStatus,
        remarks: String?,
        resolutionPhotoUri: String?,
        adminName: String
    ) = withContext(Dispatchers.IO) {
        val existing = issueDao.getIssueById(issueId) ?: return@withContext
        val now = System.currentTimeMillis()
        val resolvedTime = if (newStatus == IssueStatus.RESOLVED || newStatus == IssueStatus.CLOSED) {
            existing.resolvedAt ?: now
        } else null

        val updated = existing.copy(
            status = newStatus.name,
            adminRemarks = remarks ?: existing.adminRemarks,
            resolutionPhotoUri = resolutionPhotoUri ?: existing.resolutionPhotoUri,
            updatedAt = now,
            resolvedAt = resolvedTime
        )
        issueDao.updateIssue(updated)

        auditLogDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                issueId = issueId,
                action = "Status changed to ${newStatus.label}",
                actor = adminName,
                timestamp = now,
                notes = remarks
            )
        )

        notificationDao.insertNotification(
            CivicNotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Update on #$issueId: ${newStatus.label}",
                message = "Status updated to ${newStatus.label} by $adminName. ${remarks ?: ""}".trim(),
                issueId = issueId,
                timestamp = now,
                isRead = false,
                type = "STATUS_UPDATE"
            )
        )
    }

    suspend fun assignDepartmentAndOfficer(
        issueId: String,
        department: String,
        officer: String?,
        priority: IssuePriority,
        adminName: String
    ) = withContext(Dispatchers.IO) {
        val existing = issueDao.getIssueById(issueId) ?: return@withContext
        val now = System.currentTimeMillis()

        val updated = existing.copy(
            assignedDepartment = department,
            assignedOfficer = officer,
            priority = priority.name,
            status = if (existing.status == IssueStatus.SUBMITTED.name) IssueStatus.ASSIGNED.name else existing.status,
            updatedAt = now
        )
        issueDao.updateIssue(updated)

        auditLogDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                issueId = issueId,
                action = "Assigned to $department",
                actor = adminName,
                timestamp = now,
                notes = if (officer != null) "Assigned officer: $officer (Priority: ${priority.label})" else "Priority: ${priority.label}"
            )
        )

        notificationDao.insertNotification(
            CivicNotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Dispatched #$issueId to $department",
                message = "Assigned to $department. Officer: ${officer ?: "Pending dispatch"}.",
                issueId = issueId,
                timestamp = now,
                isRead = false,
                type = "ASSIGNMENT"
            )
        )
    }

    suspend fun syncOfflineQueue(): Int = withContext(Dispatchers.IO) {
        val issues = issueDao.getAllIssuesList().filter { !it.isSynced }
        if (issues.isNotEmpty()) {
            issueDao.markAllSynced()
            notificationDao.insertNotification(
                CivicNotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Offline Reports Synced",
                    message = "${issues.size} cached civic report(s) successfully synchronized with municipal server.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SYNC"
                )
            )
        }
        issues.size
    }

    suspend fun initializeDemoDataIfEmpty() = withContext(Dispatchers.IO) {
        val current = issueDao.getAllIssuesList()
        if (current.isNotEmpty()) return@withContext

        val now = System.currentTimeMillis()
        val oneHour = 3600_000L
        val oneDay = 86400_000L

        val demoIssues = listOf(
            CivicIssueEntity(
                id = "CF-2041",
                title = "Hazardous Deep Pothole on 4th & Main St",
                description = "Large 8-inch deep crater in the northbound right lane right in front of the public library. Causing tire damage and emergency swerving.",
                category = IssueCategory.POTHOLE_ROADS.id,
                status = IssueStatus.IN_PROGRESS.name,
                priority = IssuePriority.HIGH.name,
                latitude = 37.7749,
                longitude = -122.4194,
                address = "402 Main Street, Central District",
                photoUri = "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80",
                citizenId = "citizen_001",
                citizenName = "Alex Chen",
                isAnonymous = false,
                assignedDepartment = "Public Works Department (PWD)",
                assignedOfficer = "Engineer Sarah Kim",
                adminRemarks = "Road repair crew scheduled for cold asphalt patching tomorrow 09:00 AM.",
                upvotes = 18,
                createdAt = now - (2 * oneDay + 4 * oneHour),
                updatedAt = now - 3 * oneHour,
                isSynced = true
            ),
            CivicIssueEntity(
                id = "CF-1980",
                title = "Overflowing Community Dumpster & Waste Spill",
                description = "Commercial waste bins overflowing into pedestrian sidewalk, attracting rodents. Strong odor near residential apartments.",
                category = IssueCategory.GARBAGE_SANITATION.id,
                status = IssueStatus.RESOLVED.name,
                priority = IssuePriority.MEDIUM.name,
                latitude = 37.7785,
                longitude = -122.4140,
                address = "788 Market Boulevard, East Sector",
                photoUri = "https://images.unsplash.com/photo-1611288875785-5c086d790d97?w=600&auto=format&fit=crop&q=80",
                resolutionPhotoUri = "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600&auto=format&fit=crop&q=80",
                citizenId = "citizen_003",
                citizenName = "Elena Gomez",
                isAnonymous = false,
                assignedDepartment = "Waste Management Dept",
                assignedOfficer = "Supervisor Dave Miller",
                adminRemarks = "Dumpster emptied, high-pressure sanitization completed. Extra recycling bin installed.",
                upvotes = 12,
                createdAt = now - (3 * oneDay),
                updatedAt = now - 5 * oneHour,
                resolvedAt = now - 5 * oneHour,
                isSynced = true
            ),
            CivicIssueEntity(
                id = "CF-2104",
                title = "Broken Water Pipe Gushing on Oak Avenue",
                description = "Pressurized clean water pipe burst beneath curb. Water is flooding street intersection and reducing neighborhood pressure.",
                category = IssueCategory.WATER_SEWAGE.id,
                status = IssueStatus.ASSIGNED.name,
                priority = IssuePriority.CRITICAL.name,
                latitude = 37.7712,
                longitude = -122.4230,
                address = "120 Oak Avenue, South Gate",
                photoUri = "https://images.unsplash.com/photo-1542013936693-884638332954?w=600&auto=format&fit=crop&q=80",
                citizenId = "citizen_001",
                citizenName = "Alex Chen",
                isAnonymous = false,
                assignedDepartment = "Water Supply & Sewerage Board",
                assignedOfficer = "Chief Engineer Elena Rostova",
                adminRemarks = "Emergency isolation valve shutoff ordered. Excavation crew en route.",
                upvotes = 27,
                createdAt = now - (6 * oneHour),
                updatedAt = now - (1 * oneHour),
                isSynced = true
            ),
            CivicIssueEntity(
                id = "CF-2088",
                title = "Flickering Streetlights on Maple Walkway",
                description = "Three consecutive LED streetlights out of commission between block 14 and 16. Walking path completely dark at night.",
                category = IssueCategory.STREET_LIGHTING.id,
                status = IssueStatus.UNDER_REVIEW.name,
                priority = IssuePriority.LOW.name,
                latitude = 37.7810,
                longitude = -122.4250,
                address = "55 Maple Walkway, North Park",
                photoUri = null,
                citizenId = "citizen_004",
                citizenName = "Jordan Hayes",
                isAnonymous = true,
                assignedDepartment = "Municipal Electricity Board",
                assignedOfficer = null,
                adminRemarks = "Ballast unit inspection slated during weekly lighting audit.",
                upvotes = 5,
                createdAt = now - (1 * oneDay),
                updatedAt = now - (10 * oneHour),
                isSynced = true
            ),
            CivicIssueEntity(
                id = "CF-2150",
                title = "Malfunctioning Traffic Signal (Flashing Red)",
                description = "Signal light at busy intersection is stuck on flashing red in all four directions. Heavy morning traffic backup.",
                category = IssueCategory.TRAFFIC_SIGNALS.id,
                status = IssueStatus.SUBMITTED.name,
                priority = IssuePriority.HIGH.name,
                latitude = 37.7760,
                longitude = -122.4110,
                address = "Intersection 8th & Grand Ave",
                photoUri = null,
                citizenId = "citizen_002",
                citizenName = "Michael Brown",
                isAnonymous = false,
                assignedDepartment = "Traffic Engineering Dept",
                assignedOfficer = null,
                adminRemarks = null,
                upvotes = 9,
                createdAt = now - (2 * oneHour),
                updatedAt = now - (2 * oneHour),
                isSynced = true
            ),
            CivicIssueEntity(
                id = "CF-1902",
                title = "Fallen Tree Limb Obstructing Bike Lane",
                description = "Large pine branch fell during storm, totally blocking the dedicated bike lane and pushing cyclists into highway traffic.",
                category = IssueCategory.PARKS_TREES.id,
                status = IssueStatus.RESOLVED.name,
                priority = IssuePriority.MEDIUM.name,
                latitude = 37.7680,
                longitude = -122.4170,
                address = "230 Pine Ridge Road, West Park",
                photoUri = "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?w=600&auto=format&fit=crop&q=80",
                resolutionPhotoUri = "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=600&auto=format&fit=crop&q=80",
                citizenId = "citizen_005",
                citizenName = "David Clark",
                isAnonymous = false,
                assignedDepartment = "Parks & Greenery Dept",
                assignedOfficer = "Arborist Maya Lin",
                adminRemarks = "Limb chopped and cleared. Debris removed, bike lane swept.",
                upvotes = 11,
                createdAt = now - (5 * oneDay),
                updatedAt = now - (2 * oneDay),
                resolvedAt = now - (2 * oneDay),
                isSynced = true
            )
        )

        issueDao.insertIssues(demoIssues)

        // Seed initial audit logs
        val initialLogs = listOf(
            AuditLogEntity(
                id = "log_1",
                issueId = "CF-2041",
                action = "Report Lodged",
                actor = "Alex Chen",
                timestamp = now - (2 * oneDay + 4 * oneHour),
                notes = "Initial citizen mobile report with photo."
            ),
            AuditLogEntity(
                id = "log_2",
                issueId = "CF-2041",
                action = "Department Assigned",
                actor = "Admin Desk",
                timestamp = now - (1 * oneDay),
                notes = "Assigned to Public Works Department (PWD)"
            ),
            AuditLogEntity(
                id = "log_3",
                issueId = "CF-2041",
                action = "Status: In Progress",
                actor = "Engineer Sarah Kim",
                timestamp = now - 3 * oneHour,
                notes = "Cold mix patching team deployed."
            ),
            AuditLogEntity(
                id = "log_4",
                issueId = "CF-1980",
                action = "Report Lodged",
                actor = "Elena Gomez",
                timestamp = now - (3 * oneDay),
                notes = "Sanitation report submitted."
            ),
            AuditLogEntity(
                id = "log_5",
                issueId = "CF-1980",
                action = "Status: Resolved",
                actor = "Supervisor Dave Miller",
                timestamp = now - 5 * oneHour,
                notes = "Cleared and sanitized with proof photo attached."
            )
        )
        auditLogDao.insertLogs(initialLogs)

        // Seed initial notifications
        val initialNotifications = listOf(
            CivicNotificationEntity(
                id = "notif_1",
                title = "PWD Team Deployed for #CF-2041",
                message = "Engineer Sarah Kim was assigned to your pothole report on 4th & Main St.",
                issueId = "CF-2041",
                timestamp = now - 3 * oneHour,
                isRead = false,
                type = "STATUS_UPDATE"
            ),
            CivicNotificationEntity(
                id = "notif_2",
                title = "High Upvotes on #CF-2104",
                message = "Your water pipe issue reached 25+ upvotes from neighbors and was escalated to Critical.",
                issueId = "CF-2104",
                timestamp = now - 1 * oneHour,
                isRead = false,
                type = "UPVOTE"
            ),
            CivicNotificationEntity(
                id = "notif_3",
                title = "Issue #CF-1980 Marked Resolved",
                message = "Sanitation crew has cleared and disinfected Market Blvd dumpster. Check before/after photos.",
                issueId = "CF-1980",
                timestamp = now - 5 * oneHour,
                isRead = true,
                type = "RESOLUTION"
            )
        )
        notificationDao.insertNotifications(initialNotifications)
    }
}
