package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CivicIssueEntity::class,
        AuditLogEntity::class,
        CivicNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CivicFixDatabase : RoomDatabase() {
    abstract fun issueDao(): CivicIssueDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun notificationDao(): CivicNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: CivicFixDatabase? = null

        fun getDatabase(context: Context): CivicFixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CivicFixDatabase::class.java,
                    "civicfix_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
