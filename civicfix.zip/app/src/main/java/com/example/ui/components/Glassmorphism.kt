package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Standard curved corner radiuses for CivicFix liquid glass aesthetics.
 */
val GlassPillShape = RoundedCornerShape(percent = 50)
val GlassCardShape = RoundedCornerShape(24.dp)
val GlassLargeShape = RoundedCornerShape(28.dp)
val GlassTopBarShape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
val GlassBottomNavShape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)

/**
 * Applies a translucent liquid glass effect with chromatic light-refraction borders,
 * multi-stop translucent reflection gradient, top-edge specular gloss, and refractive lens glow.
 */
fun Modifier.liquidGlass(
    shape: Shape = GlassCardShape,
    backgroundColor: Color = Color.White.copy(alpha = 0.82f),
    tintColor: Color = Color(0xFFE0F2FE).copy(alpha = 0.45f),
    borderWidth: Dp = 1.35.dp,
    borderColorStart: Color = Color.White.copy(alpha = 0.95f), // Luminous top-edge light capture
    borderColorEnd: Color = Color(0xFF38BDF8).copy(alpha = 0.55f), // Aqua sky refraction border
    elevation: Dp = 4.dp,
    hasSpecularHighlight: Boolean = true
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        ambientColor = Color(0x280284C7),
        spotColor = Color(0x380284C7)
    )
    .clip(shape)
    .background(
        Brush.verticalGradient(
            colors = listOf(
                backgroundColor,
                tintColor,
                backgroundColor.copy(alpha = 0.92f)
            )
        )
    )
    .drawBehind {
        if (hasSpecularHighlight) {
            // Diagonal specular gloss sheen along top
            val highlightHeight = size.height * 0.38f
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.65f),
                        Color.White.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    startY = 0f,
                    endY = highlightHeight
                ),
                topLeft = Offset.Zero,
                size = Size(size.width, highlightHeight)
            )

            // Top-left subtle liquid glass refraction point
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.70f),
                        Color(0xFFE0F2FE).copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.15f, size.height * 0.12f),
                    radius = size.width * 0.40f
                ),
                radius = size.width * 0.40f,
                center = Offset(size.width * 0.15f, size.height * 0.12f)
            )

            // Bottom-right inner ambient reflection
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFBAE6FD).copy(alpha = 0.22f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.88f, size.height * 0.88f),
                    radius = size.width * 0.35f
                ),
                radius = size.width * 0.35f,
                center = Offset(size.width * 0.88f, size.height * 0.88f)
            )
        }
    }
    .border(
        width = borderWidth,
        brush = Brush.linearGradient(
            colors = listOf(
                borderColorStart,
                Color(0xFF93C5FD).copy(alpha = 0.65f),
                borderColorEnd,
                Color.White.copy(alpha = 0.60f)
            ),
            start = Offset(0f, 0f),
            end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
        ),
        shape = shape
    )

/**
 * Reusable Card with smooth curved edges, multi-layer liquid glass translucency,
 * and optional click ripple.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = GlassCardShape,
    backgroundColor: Color = Color.White.copy(alpha = 0.85f),
    tintColor: Color = Color(0xFFE0F2FE).copy(alpha = 0.45f),
    borderColorStart: Color = Color.White.copy(alpha = 0.95f),
    borderColorEnd: Color = Color(0xFF38BDF8).copy(alpha = 0.50f),
    borderWidth: Dp = 1.35.dp,
    elevation: Dp = 4.dp,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(color = Color(0xFF0284C7)),
            onClick = onClick
        )
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .liquidGlass(
                shape = shape,
                backgroundColor = backgroundColor,
                tintColor = tintColor,
                borderColorStart = borderColorStart,
                borderColorEnd = borderColorEnd,
                borderWidth = borderWidth,
                elevation = elevation
            )
            .then(clickableModifier)
            .padding(contentPadding),
        content = content
    )
}

/**
 * Liquid glass pill capsule with glossy specular shine for badges, counters, and filters.
 */
@Composable
fun LiquidGlassPill(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White.copy(alpha = 0.85f),
    tintColor: Color = Color(0xFFE0F2FE).copy(alpha = 0.50f),
    borderWidth: Dp = 1.dp,
    contentPadding: PaddingValues = PaddingValues(horizontal = 10.dp, vertical = 5.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    LiquidGlassCard(
        modifier = modifier,
        shape = GlassPillShape,
        backgroundColor = backgroundColor,
        tintColor = tintColor,
        borderWidth = borderWidth,
        elevation = 2.dp,
        onClick = onClick,
        contentPadding = contentPadding,
        content = content
    )
}

/**
 * Animated liquid backdrop canvas with glowing organic orbs that peek through
 * translucent liquid glass surfaces.
 */
@Composable
fun LiquidAmbientCanvas(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "liquid_ambient")

    val pulse1 by infiniteTransition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_1"
    )

    val pulse2 by infiniteTransition.animateFloat(
        initialValue = 1.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_2"
    )

    val drift by infiniteTransition.animateFloat(
        initialValue = -30f,
        targetValue = 30f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Base crisp luminous fluid background
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF8FAFC),
                    Color(0xFFF0F9FF)
                )
            )
        )

        // Fluid liquid orb 1: Top-Right luminous Azure Sky
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x4038BDF8),
                    Color(0x18BAE6FD),
                    Color.Transparent
                ),
                center = Offset(width * 0.85f + drift, height * 0.16f),
                radius = width * 0.60f * pulse1
            ),
            center = Offset(width * 0.85f + drift, height * 0.16f),
            radius = width * 0.60f * pulse1
        )

        // Fluid liquid orb 2: Middle-Left Aquamarine
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x352DD4BF),
                    Color(0x1499F6E4),
                    Color.Transparent
                ),
                center = Offset(width * 0.08f, height * 0.46f - drift),
                radius = width * 0.62f * pulse2
            ),
            center = Offset(width * 0.08f, height * 0.46f - drift),
            radius = width * 0.62f * pulse2
        )

        // Fluid liquid orb 3: Center-Right subtle Amber Glow (Civic action accent)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x22F59E0B),
                    Color(0x0CFE898A),
                    Color.Transparent
                ),
                center = Offset(width * 0.70f - drift, height * 0.65f),
                radius = width * 0.45f * pulse2
            ),
            center = Offset(width * 0.70f - drift, height * 0.65f),
            radius = width * 0.45f * pulse2
        )

        // Fluid liquid orb 4: Bottom-Left Soft Indigo/Violet glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x28818CF8),
                    Color(0x0EA5B4FC),
                    Color.Transparent
                ),
                center = Offset(width * 0.25f + drift, height * 0.88f),
                radius = width * 0.55f * pulse1
            ),
            center = Offset(width * 0.25f + drift, height * 0.88f),
            radius = width * 0.55f * pulse1
        )
    }
}
