package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.ui.CivicViewModel
import com.example.ui.components.CivicCameraDialog
import com.example.ui.components.CivicMapView
import com.example.ui.components.GlassCardShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.LiquidAmbientCanvas
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlass
import com.example.ui.components.PriorityBadge

@Composable
fun ReportScreen(
    viewModel: CivicViewModel,
    onReportSubmitted: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isLowBandwidth by viewModel.isLowBandwidthMode.collectAsStateWithLifecycle()
    val duplicates by viewModel.duplicateCandidates.collectAsStateWithLifecycle()
    val allIssues by viewModel.rawIssues.collectAsStateWithLifecycle()

    var selectedCategory by remember { mutableStateOf(IssueCategory.POTHOLE_ROADS) }
    var selectedPriority by remember { mutableStateOf(IssuePriority.MEDIUM) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("450 Market Street, Central City") }
    var latitude by remember { mutableDoubleStateOf(37.7752) }
    var longitude by remember { mutableDoubleStateOf(-122.4185) }
    var isAnonymous by remember { mutableStateOf(false) }
    var selectedPhotoUrl by remember {
        mutableStateOf("https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80")
    }

    var showMapPicker by remember { mutableStateOf(false) }
    var showCameraDialog by remember { mutableStateOf(false) }
    var showProximityDuplicateDialog by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var duplicateIgnored by remember { mutableStateOf(false) }

    // Trigger duplicate detection whenever category or coordinates change
    LaunchedEffect(selectedCategory, latitude, longitude) {
        viewModel.checkDuplicateCandidates(latitude, longitude, selectedCategory.id)
    }

    val sampleEvidencePhotos = listOf(
        Pair("Road Pothole", "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80"),
        Pair("Waste Spill", "https://images.unsplash.com/photo-1611288875785-5c086d790d97?w=600&auto=format&fit=crop&q=80"),
        Pair("Water Leak", "https://images.unsplash.com/photo-1542013936693-884638332954?w=600&auto=format&fit=crop&q=80"),
        Pair("Fallen Tree", "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?w=600&auto=format&fit=crop&q=80")
    )

    Box(modifier = modifier.fillMaxSize().testTag("report_issue_screen")) {
        LiquidAmbientCanvas()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Title & Civic Banner
        item {
            Column {
                Text(
                    text = "Report a Civic Issue",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Directly alert municipal authorities. Pin location, add photo, and monitor real-time repair progress.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (isLowBandwidth) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = Color(0xFFE0F2FE),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Low-Bandwidth Mode: Photos compressed to <80KB. Offline submission queue enabled.",
                                fontSize = 11.sp,
                                color = Color(0xFF0369A1),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Duplicate Detection Alert Banner
        if (duplicates.isNotEmpty() && !duplicateIgnored) {
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color(0xFFFEF3C7).copy(alpha = 0.88f),
                    tintColor = Color(0xFFFDE68A).copy(alpha = 0.6f),
                    borderColorStart = Color.White.copy(alpha = 0.9f),
                    borderColorEnd = Color(0xFFF59E0B).copy(alpha = 0.7f),
                    borderWidth = 1.25.dp,
                    elevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("duplicate_detection_alert")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFB45309),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Similar Issue Already Reported Nearby!",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E),
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "A report matching this category exists near your pinned location: \"${duplicates.first().title}\" (${duplicates.first().id}). Upvoting it will boost department priority without duplicate tickets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF78350F)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    viewModel.upvoteIssue(duplicates.first().id)
                                    onReportSubmitted(duplicates.first().id)
                                },
                                shape = GlassPillShape,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Upvote Existing", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { duplicateIgnored = true },
                                shape = GlassPillShape,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("File Separate", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Category Selection
        item {
            Column {
                Text(
                    text = "1. SELECT ISSUE CATEGORY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(IssueCategory.entries) { category ->
                        val isSelected = category == selectedCategory
                        Surface(
                            shape = GlassCardShape,
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.82f),
                            border = if (isSelected) {
                                CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary))
                            } else CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF94A3B8))),
                            shadowElevation = if (isSelected) 3.dp else 1.dp,
                            modifier = Modifier
                                .liquidGlass(
                                    shape = GlassCardShape,
                                    backgroundColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.88f) else Color.White.copy(alpha = 0.82f),
                                    borderColorStart = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFF94A3B8),
                                    borderColorEnd = if (isSelected) Color(0xFF0284C7) else Color(0xFFCBD5E1),
                                    borderWidth = if (isSelected) 1.5.dp else 1.2.dp,
                                    elevation = if (isSelected) 3.dp else 1.dp
                                )
                                .clickable {
                                    selectedCategory = category
                                    duplicateIgnored = false
                                }
                                .semantics {
                                    contentDescription = "Category ${category.title}"
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = category.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Urgency / Priority Selection
        item {
            Column {
                Text(
                    text = "2. URGENCY LEVEL",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IssuePriority.entries.forEach { priority ->
                        val isSelected = priority == selectedPriority
                        Surface(
                            shape = GlassPillShape,
                            color = if (isSelected) priority.color.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.7f),
                            border = if (isSelected) {
                                CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(priority.color))
                            } else CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF94A3B8))),
                            modifier = Modifier
                                .weight(1f)
                                .liquidGlass(
                                    shape = GlassPillShape,
                                    backgroundColor = if (isSelected) priority.color.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.7f),
                                    borderColorStart = if (isSelected) priority.color else Color(0xFF94A3B8),
                                    borderColorEnd = if (isSelected) priority.color.copy(alpha = 0.7f) else Color(0xFFCBD5E1),
                                    borderWidth = if (isSelected) 1.5.dp else 1.2.dp,
                                    elevation = 1.dp
                                )
                                .clickable { selectedPriority = priority }
                                .semantics {
                                    contentDescription = "Priority ${priority.label}"
                                }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            ) {
                                Text(
                                    text = priority.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) priority.color else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Title and Description fields
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "3. ISSUE DETAILS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        validationError = null
                    },
                    label = { Text("Title / Summary *") },
                    placeholder = { Text("e.g., Deep pothole causing hazard") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("issue_title_input")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = {
                        description = it
                        validationError = null
                    },
                    label = { Text("Detailed Description *") },
                    placeholder = { Text("Describe location landmark, severity, obstruction, and safety risk...") },
                    minLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("issue_description_input")
                )
            }
        }

        // Evidence Photo Attachment
        item {
            Column {
                Text(
                    text = "4. PHOTO EVIDENCE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Capture a live photo using CameraX or select a preset civic photo:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(8.dp))

                // CameraX Capture Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showCameraDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = GlassPillShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlass(
                                shape = GlassPillShape,
                                backgroundColor = MaterialTheme.colorScheme.primary,
                                borderWidth = 1.dp,
                                elevation = 3.dp
                            )
                            .testTag("open_camera_button")
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Capture Photo with CameraX", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Photo preview
                if (selectedPhotoUrl.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = selectedPhotoUrl,
                            contentDescription = "Selected issue evidence photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.65f),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = if (selectedPhotoUrl.startsWith("file:") || selectedPhotoUrl.startsWith("content:") || selectedPhotoUrl.contains("civic_evidence"))
                                    "Live CameraX Capture (${if (isLowBandwidth) "<80KB Compressed" else "Original"})"
                                else if (isLowBandwidth) "Compressed (64KB)" else "Preset Civic Photo",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Sample Presets Row for convenience
                Text(
                    text = "Or Choose Quick Preset:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sampleEvidencePhotos) { (label, url) ->
                        val isPicked = selectedPhotoUrl == url
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isPicked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { selectedPhotoUrl = url }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                if (isPicked) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        // Location & Interactive Map Pinpoint
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "5. EXACT LOCATION & GPS PIN",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedButton(
                        onClick = { showMapPicker = !showMapPicker },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showMapPicker) "Hide Map" else "Pinpoint on Map", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Street Address / Landmark *") },
                    leadingIcon = {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("issue_address_input")
                )

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lat: ${"%.4f".format(latitude)}, Lon: ${"%.4f".format(longitude)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    OutlinedButton(
                        onClick = {
                            // Detect current GPS position anchor
                            latitude = 37.7749 + ((0..20).random() - 10) * 0.0005
                            longitude = -122.4194 + ((0..20).random() - 10) * 0.0005
                            address = "Current GPS Position (Near Civic Center)"
                            duplicateIgnored = false
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Use GPS Location", fontSize = 10.sp)
                    }
                }

                if (showMapPicker) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tap anywhere on the city map to reposition your complaint pin:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.25.dp, Color(0xFF94A3B8), RoundedCornerShape(16.dp))
                    ) {
                        CivicMapView(
                            issues = allIssues,
                            selectedIssue = null,
                            onIssueSelected = {},
                            isSelectionMode = true,
                            selectedCoordinates = Pair(latitude, longitude),
                            onCoordinatesSelected = { newLat, newLon ->
                                latitude = newLat
                                longitude = newLon
                                address = "Pinned Location (${"%.4f".format(newLat)}, ${"%.4f".format(newLon)})"
                                duplicateIgnored = false
                            }
                        )
                    }
                }
            }
        }

        // Privacy & Anonymous Reporting Switch
        item {
            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.85f),
                tintColor = Color(0xFFF0F9FF).copy(alpha = 0.5f),
                borderWidth = 1.dp,
                elevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Report Anonymously",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Mask your name and personal contact details from public record while maintaining ticket tracking.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isAnonymous,
                        onCheckedChange = { isAnonymous = it },
                        modifier = Modifier.testTag("anonymous_reporting_toggle")
                    )
                }
            }
        }

        // Error message if any
        if (validationError != null) {
            item {
                Text(
                    text = validationError ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Submit Button
        item {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        validationError = "Please enter an issue title/summary."
                        return@Button
                    }
                    if (description.isBlank()) {
                        validationError = "Please provide a detailed description."
                        return@Button
                    }
                    if (address.isBlank()) {
                        validationError = "Please specify the issue street address."
                        return@Button
                    }

                    val performSubmission = {
                        viewModel.submitNewComplaint(
                            title = title.trim(),
                            description = description.trim(),
                            category = selectedCategory,
                            priority = selectedPriority,
                            latitude = latitude,
                            longitude = longitude,
                            address = address.trim(),
                            photoUri = selectedPhotoUrl.ifBlank { null },
                            isAnonymous = isAnonymous,
                            onSuccess = { newId ->
                                onReportSubmitted(newId)
                            }
                        )
                    }

                    // Check if duplicate exists within proximity threshold
                    if (duplicates.isNotEmpty() && !duplicateIgnored) {
                        showProximityDuplicateDialog = true
                    } else {
                        performSubmission()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .liquidGlass(
                        shape = GlassPillShape,
                        backgroundColor = MaterialTheme.colorScheme.primary,
                        borderWidth = 1.25.dp,
                        elevation = 4.dp
                    )
                    .testTag("submit_report_button"),
                shape = GlassPillShape,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = "Submit Civic Report",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (showProximityDuplicateDialog && duplicates.isNotEmpty()) {
        val candidate = duplicates.first()
        AlertDialog(
            onDismissRequest = { showProximityDuplicateDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Nearby Duplicate Detected",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Our proximity detection helper discovered an existing issue nearby:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = candidate.title,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "Ticket #${candidate.id} • ${candidate.address}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    Text(
                        text = "Would you prefer to upvote the existing ticket to fast-track repairs, or still file a new report?",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.upvoteIssue(candidate.id)
                        showProximityDuplicateDialog = false
                        onReportSubmitted(candidate.id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Upvote Existing", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        duplicateIgnored = true
                        showProximityDuplicateDialog = false
                        viewModel.submitNewComplaint(
                            title = title.trim(),
                            description = description.trim(),
                            category = selectedCategory,
                            priority = selectedPriority,
                            latitude = latitude,
                            longitude = longitude,
                            address = address.trim(),
                            photoUri = selectedPhotoUrl.ifBlank { null },
                            isAnonymous = isAnonymous,
                            onSuccess = { newId ->
                                onReportSubmitted(newId)
                            }
                        )
                    }
                ) {
                    Text("Submit Anyway", color = Color(0xFF64748B))
                }
            }
        )
    }
}

    if (showCameraDialog) {
        CivicCameraDialog(
            onDismissRequest = { showCameraDialog = false },
            onPhotoCaptured = { uri, _ ->
                selectedPhotoUrl = uri.toString()
                showCameraDialog = false
            }
        )
    }
}
