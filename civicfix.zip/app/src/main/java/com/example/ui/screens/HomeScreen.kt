package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.CivicIssueEntity
import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.model.UserRole
import com.example.ui.CivicViewModel
import com.example.ui.components.GlassCardShape
import com.example.ui.components.GlassLargeShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.PriorityBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.SyncStatusIndicator
import com.example.ui.components.liquidGlass
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: CivicViewModel,
    onIssueClick: (String) -> Unit,
    modifier: Modifier = Modifier,
    onOpenAdminLogin: (() -> Unit)? = null
) {
    val issues by viewModel.filteredIssues.collectAsStateWithLifecycle()
    val allRawIssues by viewModel.rawIssues.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val isLowBandwidth by viewModel.isLowBandwidthMode.collectAsStateWithLifecycle()

    val pendingSyncCount = allRawIssues.count { !it.isSynced }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_feed"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Header Section with curved liquid glass styling
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .height(180.dp)
                    .liquidGlass(
                        shape = GlassLargeShape,
                        backgroundColor = Color.Transparent,
                        borderWidth = 1.5.dp,
                        borderColorStart = Color(0xFFCBD5E1),
                        borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.6f),
                        elevation = 6.dp
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.civic_hero_banner),
                    contentDescription = "CivicFix municipal landscape banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(GlassLargeShape)
                )

                // Luminous sky-blue liquid gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(GlassLargeShape)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x550284C7),
                                    Color(0xDD0369A1)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "COMMUNITY RESOLUTION FEED",
                            color = Color(0xFFBAE6FD),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )

                        if (onOpenAdminLogin != null) {
                            Surface(
                                shape = GlassPillShape,
                                color = Color.White.copy(alpha = 0.25f),
                                modifier = Modifier
                                    .clickable { onOpenAdminLogin() }
                                    .testTag("home_admin_portal_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.VpnKey,
                                        contentDescription = "Admin Login",
                                        tint = Color(0xFFFEF08A),
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Admin Portal",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Report, Track & Fix Your City",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${allRawIssues.size} Total Reports • ${allRawIssues.count { it.status == "RESOLVED" }} Resolved",
                        color = Color(0xFFF0F9FF),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Offline / Low Bandwidth Pending Sync Banner
        if (pendingSyncCount > 0) {
            item {
                Surface(
                    color = Color(0xFFFEF3C7).copy(alpha = 0.90f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .liquidGlass(
                            shape = GlassCardShape,
                            backgroundColor = Color(0xFFFEF3C7).copy(alpha = 0.90f),
                            tintColor = Color(0xFFFDE68A).copy(alpha = 0.5f),
                            borderColorStart = Color(0xFFD97706),
                            borderColorEnd = Color(0xFFF59E0B),
                            borderWidth = 1.35.dp,
                            elevation = 2.dp
                        ),
                    shape = GlassCardShape
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "$pendingSyncCount offline report(s) cached",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "Low-bandwidth queue will push when connected",
                                color = Color(0xFFB45309),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(
                            onClick = { viewModel.syncPendingOfflineQueue() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = GlassPillShape,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.liquidGlass(
                                shape = GlassPillShape,
                                backgroundColor = Color(0xFFD97706),
                                borderWidth = 1.dp,
                                elevation = 2.dp
                            )
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sync Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Search Bar with curved glass pill shape
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = {
                        Text(
                            "Search ticket #, issue, or address...",
                            color = MaterialTheme.colorScheme.outline
                        )
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Search complaints",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, GlassPillShape, ambientColor = Color(0x150284C7))
                        .testTag("search_complaints_input"),
                    shape = GlassPillShape,
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White.copy(alpha = 0.95f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.85f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color(0xFF94A3B8)
                    )
                )
            }
        }

        // Category Filter Chips
        item {
            Column(modifier = Modifier.padding(bottom = 8.dp)) {
                Text(
                    text = "CATEGORIES",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null || selectedCategory == "ALL",
                            onClick = { viewModel.setCategoryFilter("ALL") },
                            label = { Text("All") },
                            shape = GlassPillShape,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedCategory == null || selectedCategory == "ALL",
                                borderColor = Color(0xFF94A3B8),
                                selectedBorderColor = MaterialTheme.colorScheme.primary,
                                borderWidth = 1.25.dp,
                                selectedBorderWidth = 1.5.dp
                            ),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = Color.White.copy(alpha = 0.82f)
                            )
                        )
                    }
                    items(IssueCategory.entries) { cat ->
                        val isSel = selectedCategory == cat.id
                        FilterChip(
                            selected = isSel,
                            onClick = {
                                viewModel.setCategoryFilter(if (isSel) "ALL" else cat.id)
                            },
                            leadingIcon = {
                                Icon(
                                    cat.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text(cat.title) },
                            shape = GlassPillShape,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSel,
                                borderColor = Color(0xFF94A3B8),
                                selectedBorderColor = MaterialTheme.colorScheme.primary,
                                borderWidth = 1.25.dp,
                                selectedBorderWidth = 1.5.dp
                            ),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = Color.White.copy(alpha = 0.82f)
                            )
                        )
                    }
                }
            }
        }

        // Status Filter Chips
        item {
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Text(
                    text = "STATUS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedStatus == null || selectedStatus == "ALL",
                            onClick = { viewModel.setStatusFilter("ALL") },
                            label = { Text("All Statuses") },
                            shape = GlassPillShape,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedStatus == null || selectedStatus == "ALL",
                                borderColor = Color(0xFF94A3B8),
                                selectedBorderColor = MaterialTheme.colorScheme.primary,
                                borderWidth = 1.25.dp,
                                selectedBorderWidth = 1.5.dp
                            ),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = Color.White.copy(alpha = 0.82f)
                            )
                        )
                    }
                    items(IssueStatus.entries) { stat ->
                        val isSel = selectedStatus == stat.name
                        FilterChip(
                            selected = isSel,
                            onClick = {
                                viewModel.setStatusFilter(if (isSel) "ALL" else stat.name)
                            },
                            label = { Text(stat.label) },
                            shape = GlassPillShape,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSel,
                                borderColor = Color(0xFF94A3B8),
                                selectedBorderColor = MaterialTheme.colorScheme.primary,
                                borderWidth = 1.25.dp,
                                selectedBorderWidth = 1.5.dp
                            ),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = Color.White.copy(alpha = 0.82f)
                            )
                        )
                    }
                }
            }
        }

        // Complaint List Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reported Issues (${issues.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (user.role == UserRole.ADMIN) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Admin View",
                            color = Color(0xFFB45309),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Empty state
        if (issues.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.FilterList,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No civic issues match your filters",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing search keywords or selecting 'All' categories.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            items(issues, key = { it.id }) { issue ->
                CivicIssueCard(
                    issue = issue,
                    isLowBandwidth = isLowBandwidth,
                    onClick = { onIssueClick(issue.id) },
                    onUpvote = { viewModel.upvoteIssue(issue.id) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun CivicIssueCard(
    issue: CivicIssueEntity,
    isLowBandwidth: Boolean,
    onClick: () -> Unit,
    onUpvote: () -> Unit,
    modifier: Modifier = Modifier
) {
    val category = IssueCategory.fromId(issue.category)
    val status = IssueStatus.fromName(issue.status)
    val priority = IssuePriority.fromName(issue.priority)
    val formattedDate = remember(issue.createdAt) {
        val sdf = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
        sdf.format(Date(issue.createdAt))
    }

    LiquidGlassCard(
        shape = GlassCardShape,
        backgroundColor = Color.White.copy(alpha = 0.88f),
        tintColor = Color(0xFFF0F9FF).copy(alpha = 0.65f),
        borderWidth = 1.25.dp,
        elevation = 4.dp,
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("issue_card_${issue.id}")
            .semantics {
                contentDescription = "Report ${issue.id}: ${issue.title}, Status ${status.label}, Priority ${priority.label}"
            }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Category Icon + ID + Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .size(36.dp)
                            .shadow(2.dp, CircleShape, ambientColor = Color(0x300284C7))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = category.icon,
                                contentDescription = category.title,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = issue.id,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = category.title,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PriorityBadge(priority = priority)
                    StatusBadge(status = status)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title & Description
            Text(
                text = issue.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = issue.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Photo preview if available and not ultra-low-bandwidth
            if (!issue.photoUri.isNullOrBlank() && !isLowBandwidth) {
                Spacer(modifier = Modifier.height(12.dp))
                AsyncImage(
                    model = issue.photoUri,
                    contentDescription = "Citizen attached evidence photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .shadow(2.dp, RoundedCornerShape(16.dp))
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Address & Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = issue.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer: Department + Sync Status + Upvote Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = issue.assignedDepartment ?: "Pending Dispatch",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                        fontSize = 10.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!issue.isSynced) {
                        SyncStatusIndicator(isSynced = false)
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    // Upvote button with curved glass pill
                    Surface(
                        shape = GlassPillShape,
                        color = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier
                            .liquidGlass(
                                shape = GlassPillShape,
                                backgroundColor = Color.White.copy(alpha = 0.85f),
                                tintColor = Color(0xFFE0F2FE).copy(alpha = 0.5f),
                                borderColorStart = Color(0xFF94A3B8),
                                borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.5f),
                                borderWidth = 1.25.dp,
                                elevation = 1.dp
                            )
                            .clickable { onUpvote() }
                            .semantics {
                                contentDescription = "Upvote issue, current votes ${issue.upvotes}"
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.ThumbUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${issue.upvotes}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}
