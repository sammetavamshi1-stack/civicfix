package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bright White & Luminous Civic Theme Tokens
val CivicPrimary = Color(0xFF0284C7)
val CivicOnPrimary = Color(0xFFFFFFFF)
val CivicPrimaryContainer = Color(0xFFE0F2FE)
val CivicOnPrimaryContainer = Color(0xFF0369A1)

val CivicSecondary = Color(0xFF0D9488)
val CivicOnSecondary = Color(0xFFFFFFFF)
val CivicSecondaryContainer = Color(0xFFCCFBF1)
val CivicOnSecondaryContainer = Color(0xFF115E59)

val CivicTertiary = Color(0xFF4F46E5)
val CivicOnTertiary = Color(0xFFFFFFFF)
val CivicTertiaryContainer = Color(0xFFEEF2FF)
val CivicOnTertiaryContainer = Color(0xFF3730A3)

val CivicBackground = Color(0xFFFFFFFF)
val CivicOnBackground = Color(0xFF0F172A)
val CivicSurface = Color(0xFFFFFFFF)
val CivicOnSurface = Color(0xFF0F172A)
val CivicSurfaceVariant = Color(0xFFF8FAFC)
val CivicOnSurfaceVariant = Color(0xFF475569)
val CivicOutline = Color(0xFFCBD5E1)
val CivicOutlineVariant = Color(0xFFE2E8F0)

val CivicError = Color(0xFFEF4444)
val CivicOnError = Color(0xFFFFFFFF)
val CivicErrorContainer = Color(0xFFFEE2E2)
val CivicOnErrorContainer = Color(0xFF991B1B)

// Status Colors
val StatusSubmitted = Color(0xFF6366F1)
val StatusUnderReview = Color(0xFF0284C7)
val StatusAssigned = Color(0xFFF59E0B)
val StatusInProgress = Color(0xFFF97316)
val StatusResolved = Color(0xFF10B981)
val StatusClosed = Color(0xFF64748B)

// Urgency Colors
val PriorityLow = Color(0xFF0284C7)
val PriorityMedium = Color(0xFFF59E0B)
val PriorityHigh = Color(0xFFF97316)
val PriorityCritical = Color(0xFFEF4444)

// Dark Theme Tokens (Kept clean and high contrast)
val CivicPrimaryDark = Color(0xFF38BDF8)
val CivicOnPrimaryDark = Color(0xFF003554)
val CivicBackgroundDark = Color(0xFFF8FAFC)
val CivicOnBackgroundDark = Color(0xFF0F172A)
val CivicSurfaceDark = Color(0xFFFFFFFF)
val CivicOnSurfaceDark = Color(0xFF0F172A)

