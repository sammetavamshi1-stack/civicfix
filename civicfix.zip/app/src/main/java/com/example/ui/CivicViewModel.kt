package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AuditLogEntity
import com.example.data.CivicFixDatabase
import com.example.data.CivicIssueEntity
import com.example.data.CivicNotificationEntity
import com.example.data.CivicRepository
import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.model.UserRole
import com.example.model.UserSession
import com.example.service.ProximityDuplicateDetectionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AnalyticsData(
    val totalComplaints: Int = 0,
    val resolvedComplaints: Int = 0,
    val inProgressComplaints: Int = 0,
    val pendingReviewComplaints: Int = 0,
    val resolutionRatePercent: Int = 0,
    val avgResolutionDays: Double = 2.4,
    val categoryCounts: Map<String, Int> = emptyMap(),
    val statusCounts: Map<String, Int> = emptyMap(),
    val departmentCounts: Map<String, Int> = emptyMap()
)

class CivicViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CivicRepository
    private val proximityHelper = ProximityDuplicateDetectionHelper(proximityThresholdMeters = 350.0)

    init {
        val db = CivicFixDatabase.getDatabase(application)
        repository = CivicRepository(db)
        viewModelScope.launch {
            repository.initializeDemoDataIfEmpty()
        }
    }

    // User session & RBAC
    private val _currentUser = MutableStateFlow(
        UserSession(
            id = "citizen_001",
            name = "Alex Chen",
            email = "alex.chen@citycivic.org",
            role = UserRole.CITIZEN
        )
    )
    val currentUser: StateFlow<UserSession> = _currentUser.asStateFlow()

    // Low bandwidth / offline simulation mode
    private val _isLowBandwidthMode = MutableStateFlow(false)
    val isLowBandwidthMode: StateFlow<Boolean> = _isLowBandwidthMode.asStateFlow()

    // Filter states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<String?>("ALL")
    val selectedCategoryFilter: StateFlow<String?> = _selectedCategoryFilter.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<String?>("ALL")
    val selectedStatusFilter: StateFlow<String?> = _selectedStatusFilter.asStateFlow()

    private val _selectedPriorityFilter = MutableStateFlow<String?>("ALL")
    val selectedPriorityFilter: StateFlow<String?> = _selectedPriorityFilter.asStateFlow()

    private val _selectedDepartmentFilter = MutableStateFlow<String?>("ALL")
    val selectedDepartmentFilter: StateFlow<String?> = _selectedDepartmentFilter.asStateFlow()

    private val _showOnlyMyReports = MutableStateFlow(false)
    val showOnlyMyReports: StateFlow<Boolean> = _showOnlyMyReports.asStateFlow()

    // Raw issues from Room
    val rawIssues: StateFlow<List<CivicIssueEntity>> = repository.allIssues
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notifications
    val notifications: StateFlow<List<CivicNotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private data class CivicFilterState(
        val query: String,
        val cat: String?,
        val stat: String?,
        val prio: String?,
        val dept: String?,
        val onlyMine: Boolean,
        val user: UserSession
    )

    private val filterState = combine(
        combine(_searchQuery, _selectedCategoryFilter, _selectedStatusFilter) { q, c, s -> Triple(q, c, s) },
        combine(_selectedPriorityFilter, _selectedDepartmentFilter, _showOnlyMyReports) { p, d, m -> Triple(p, d, m) },
        _currentUser
    ) { (q, c, s), (p, d, m), u ->
        CivicFilterState(q, c, s, p, d, m, u)
    }

    // Filtered issues combining filters
    val filteredIssues: StateFlow<List<CivicIssueEntity>> = combine(rawIssues, filterState) { issues, filters ->
        issues.filter { issue ->
            val matchesQuery = filters.query.isBlank() ||
                    issue.title.contains(filters.query, ignoreCase = true) ||
                    issue.description.contains(filters.query, ignoreCase = true) ||
                    issue.address.contains(filters.query, ignoreCase = true) ||
                    issue.id.contains(filters.query, ignoreCase = true)

            val matchesCat = filters.cat == null || filters.cat == "ALL" || issue.category.equals(filters.cat, ignoreCase = true)
            val matchesStat = filters.stat == null || filters.stat == "ALL" || issue.status.equals(filters.stat, ignoreCase = true)
            val matchesPrio = filters.prio == null || filters.prio == "ALL" || issue.priority.equals(filters.prio, ignoreCase = true)
            val matchesDept = filters.dept == null || filters.dept == "ALL" || issue.assignedDepartment.equals(filters.dept, ignoreCase = true)
            val matchesMine = !filters.onlyMine || issue.citizenId == filters.user.id

            matchesQuery && matchesCat && matchesStat && matchesPrio && matchesDept && matchesMine
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Analytics computation derived from raw issues
    val analytics: StateFlow<AnalyticsData> = rawIssues.combine(_currentUser) { issues, _ ->
        val total = issues.size
        val resolved = issues.count { it.status == IssueStatus.RESOLVED.name || it.status == IssueStatus.CLOSED.name }
        val inProgress = issues.count { it.status == IssueStatus.IN_PROGRESS.name || it.status == IssueStatus.ASSIGNED.name }
        val pending = issues.count { it.status == IssueStatus.SUBMITTED.name || it.status == IssueStatus.UNDER_REVIEW.name }
        val rate = if (total > 0) (resolved * 100) / total else 0

        val catMap = mutableMapOf<String, Int>()
        IssueCategory.entries.forEach { catMap[it.title] = 0 }
        issues.forEach { issue ->
            val catObj = IssueCategory.fromId(issue.category)
            catMap[catObj.title] = (catMap[catObj.title] ?: 0) + 1
        }

        val statMap = mutableMapOf<String, Int>()
        IssueStatus.entries.forEach { statMap[it.label] = 0 }
        issues.forEach { issue ->
            val stObj = IssueStatus.fromName(issue.status)
            statMap[stObj.label] = (statMap[stObj.label] ?: 0) + 1
        }

        val deptMap = mutableMapOf<String, Int>()
        issues.forEach { issue ->
            val d = issue.assignedDepartment ?: "Unassigned"
            deptMap[d] = (deptMap[d] ?: 0) + 1
        }

        AnalyticsData(
            totalComplaints = total,
            resolvedComplaints = resolved,
            inProgressComplaints = inProgress,
            pendingReviewComplaints = pending,
            resolutionRatePercent = rate,
            avgResolutionDays = 1.9,
            categoryCounts = catMap,
            statusCounts = statMap,
            departmentCounts = deptMap
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AnalyticsData())

    // Selected issue for detail/tracking view
    private val _selectedIssueId = MutableStateFlow<String?>(null)
    val selectedIssueId: StateFlow<String?> = _selectedIssueId.asStateFlow()

    private val _selectedIssueLogs = MutableStateFlow<List<AuditLogEntity>>(emptyList())
    val selectedIssueLogs: StateFlow<List<AuditLogEntity>> = _selectedIssueLogs.asStateFlow()

    // Duplicate detection state during filing
    private val _duplicateCandidates = MutableStateFlow<List<CivicIssueEntity>>(emptyList())
    val duplicateCandidates: StateFlow<List<CivicIssueEntity>> = _duplicateCandidates.asStateFlow()

    // Filter controls
    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setCategoryFilter(c: String?) { _selectedCategoryFilter.value = c }
    fun setStatusFilter(s: String?) { _selectedStatusFilter.value = s }
    fun setPriorityFilter(p: String?) { _selectedPriorityFilter.value = p }
    fun setDepartmentFilter(d: String?) { _selectedDepartmentFilter.value = d }
    fun setShowOnlyMyReports(mine: Boolean) { _showOnlyMyReports.value = mine }

    fun toggleRole() {
        val current = _currentUser.value
        _currentUser.value = if (current.role == UserRole.CITIZEN) {
            UserSession(
                id = "admin_001",
                name = "Director Sterling",
                email = "director.sterling@citycivic.gov",
                role = UserRole.ADMIN,
                department = "Municipal Operations Command"
            )
        } else {
            UserSession(
                id = "citizen_001",
                name = "Alex Chen",
                email = "alex.chen@citycivic.org",
                role = UserRole.CITIZEN
            )
        }
    }

    fun loginAsAdmin(badgeId: String, name: String, department: String) {
        _currentUser.value = UserSession(
            id = badgeId,
            name = name,
            email = "${badgeId.lowercase().replace("-", ".")}@citycivic.gov",
            role = UserRole.ADMIN,
            department = department
        )
    }

    fun logoutToCitizen() {
        _currentUser.value = UserSession(
            id = "citizen_001",
            name = "Alex Chen",
            email = "alex.chen@citycivic.org",
            role = UserRole.CITIZEN
        )
    }

    fun toggleLowBandwidthMode() {
        _isLowBandwidthMode.value = !_isLowBandwidthMode.value
    }

    fun selectIssue(id: String?) {
        _selectedIssueId.value = id
        if (id != null) {
            viewModelScope.launch {
                repository.getAuditLogsForIssue(id).collect { logs ->
                    _selectedIssueLogs.value = logs
                }
            }
        } else {
            _selectedIssueLogs.value = emptyList()
        }
    }

    fun upvoteIssue(id: String) {
        viewModelScope.launch {
            repository.upvoteIssue(id)
        }
    }

    fun checkDuplicateCandidates(lat: Double, lon: Double, category: String) {
        viewModelScope.launch {
            val allExisting = rawIssues.value
            val result = proximityHelper.checkNearbyDuplicates(
                targetLatitude = lat,
                targetLongitude = lon,
                targetCategory = category,
                existingIssues = allExisting
            )
            _duplicateCandidates.value = result.matchingCandidates.map { it.issue }
        }
    }

    fun clearDuplicateCandidates() {
        _duplicateCandidates.value = emptyList()
    }

    fun submitNewComplaint(
        title: String,
        description: String,
        category: IssueCategory,
        priority: IssuePriority,
        latitude: Double,
        longitude: Double,
        address: String,
        photoUri: String?,
        isAnonymous: Boolean,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val user = _currentUser.value
            val issue = repository.reportIssue(
                title = title,
                description = description,
                category = category,
                priority = priority,
                latitude = latitude,
                longitude = longitude,
                address = address,
                photoUri = photoUri,
                citizenId = user.id,
                citizenName = user.name,
                isAnonymous = isAnonymous,
                isLowBandwidthMode = _isLowBandwidthMode.value
            )
            clearDuplicateCandidates()
            onSuccess(issue.id)
        }
    }

    fun adminUpdateStatus(
        issueId: String,
        newStatus: IssueStatus,
        remarks: String?,
        resolutionPhotoUri: String?
    ) {
        viewModelScope.launch {
            repository.updateIssueStatus(
                issueId = issueId,
                newStatus = newStatus,
                remarks = remarks,
                resolutionPhotoUri = resolutionPhotoUri,
                adminName = _currentUser.value.name
            )
        }
    }

    fun adminAssignDepartment(
        issueId: String,
        department: String,
        officer: String?,
        priority: IssuePriority
    ) {
        viewModelScope.launch {
            repository.assignDepartmentAndOfficer(
                issueId = issueId,
                department = department,
                officer = officer,
                priority = priority,
                adminName = _currentUser.value.name
            )
        }
    }

    fun syncPendingOfflineQueue() {
        viewModelScope.launch {
            repository.syncOfflineQueue()
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }
}
