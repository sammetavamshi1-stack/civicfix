package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CivicIssueEntity
import com.example.model.IssueCategory
import com.example.model.IssueStatus
import com.example.ui.CivicViewModel
import com.example.ui.components.CivicMapView

import androidx.compose.ui.graphics.Color
import com.example.ui.components.GlassPillShape

@Composable
fun MapScreen(
    viewModel: CivicViewModel,
    onIssueSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredIssues by viewModel.filteredIssues.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    var activePreviewIssue by remember { mutableStateOf<CivicIssueEntity?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_screen")
    ) {
        CivicMapView(
            issues = filteredIssues,
            selectedIssue = activePreviewIssue,
            onIssueSelected = { issue ->
                if (issue != null && issue.id == activePreviewIssue?.id) {
                    onIssueSelected(issue.id)
                } else {
                    activePreviewIssue = issue
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top Filter Bar Overlay
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    val isAll = selectedStatus == null || selectedStatus == "ALL"
                    FilterChip(
                        selected = isAll,
                        onClick = { viewModel.setStatusFilter("ALL") },
                        label = { Text("All (${filteredIssues.size})") },
                        shape = GlassPillShape,
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isAll,
                            borderColor = Color(0xFF94A3B8),
                            selectedBorderColor = MaterialTheme.colorScheme.primary,
                            borderWidth = 1.25.dp,
                            selectedBorderWidth = 1.5.dp
                        ),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            containerColor = Color.White.copy(alpha = 0.88f)
                        )
                    )
                }
                items(IssueStatus.entries) { stat ->
                    val isSel = selectedStatus == stat.name
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            viewModel.setStatusFilter(if (isSel) "ALL" else stat.name)
                        },
                        label = { Text(stat.label) },
                        shape = GlassPillShape,
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSel,
                            borderColor = Color(0xFF94A3B8),
                            selectedBorderColor = stat.color,
                            borderWidth = 1.25.dp,
                            selectedBorderWidth = 1.5.dp
                        ),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = stat.color.copy(alpha = 0.22f),
                            selectedLabelColor = stat.color,
                            containerColor = Color.White.copy(alpha = 0.88f)
                        )
                    )
                }
            }
        }
    }
}
