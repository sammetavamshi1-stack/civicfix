package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CivicIssueEntity
import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.ui.CivicViewModel
import com.example.ui.components.CivicBarChart
import com.example.ui.components.CivicKpiCard
import com.example.ui.components.CivicStatusDonutChart
import com.example.ui.components.GlassCardShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.GlassTopBarShape
import com.example.ui.components.LiquidAmbientCanvas
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.PriorityBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.liquidGlass
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: CivicViewModel,
    onIssueClick: (String) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allRawIssues by viewModel.rawIssues.collectAsStateWithLifecycle()
    val analytics by viewModel.analytics.collectAsStateWithLifecycle()

    var selectedAdminSection by remember { mutableStateOf(0) } // 0: Ticket Dispatch & Triage, 1: Municipal Analytics, 2: Department Roster
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<String?>("PENDING_REVIEW") }
    var selectedDeptFilter by remember { mutableStateOf<String?>(null) }

    // Dialog state for rapid inline triage
    var quickActionIssue by remember { mutableStateOf<CivicIssueEntity?>(null) }
    var newStatusTarget by remember { mutableStateOf(IssueStatus.IN_PROGRESS) }
    var newDeptTarget by remember { mutableStateOf("Public Works Department (PWD)") }
    var officerAssigned by remember { mutableStateOf("") }
    var triageRemarks by remember { mutableStateOf("") }

    val departments = listOf(
        "All Departments",
        "Public Works Department (PWD)",
        "Waste Management Dept",
        "Water Supply & Sewerage",
        "Municipal Electricity Board",
        "Parks & Greenery Dept",
        "Traffic Engineering Dept"
    )

    val filteredIssues = remember(allRawIssues, searchQuery, selectedStatusFilter, selectedDeptFilter) {
        allRawIssues.filter { issue ->
            val matchesQuery = searchQuery.isBlank() ||
                    issue.title.contains(searchQuery, ignoreCase = true) ||
                    issue.id.contains(searchQuery, ignoreCase = true) ||
                    issue.address.contains(searchQuery, ignoreCase = true)

            val matchesStatus = selectedStatusFilter == null || selectedStatusFilter == "ALL" || issue.status == selectedStatusFilter

            val matchesDept = selectedDeptFilter == null || selectedDeptFilter == "All Departments" ||
                    issue.assignedDepartment?.contains(selectedDeptFilter ?: "", ignoreCase = true) == true

            matchesQuery && matchesStatus && matchesDept
        }
    }

    Box(modifier = modifier.fillMaxSize().testTag("admin_dashboard_screen")) {
        LiquidAmbientCanvas()

        Column(modifier = Modifier.fillMaxSize()) {
            // Municipal Admin Top Command Bar with Liquid Glass Translucency
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlass(
                        shape = GlassTopBarShape,
                        backgroundColor = Color(0xFF0F172A).copy(alpha = 0.92f),
                        tintColor = Color(0xFF1E293B).copy(alpha = 0.75f),
                        borderColorStart = Color.White.copy(alpha = 0.35f),
                        borderColorEnd = Color(0xFF38BDF8).copy(alpha = 0.50f),
                        borderWidth = 1.25.dp,
                        elevation = 6.dp
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFFEF3C7),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = Color(0xFFB45309),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "MUNICIPAL ADMIN PORTAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFBBF24),
                                        letterSpacing = 1.sp
                                    )
                                }
                                Text(
                                    text = currentUser.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = currentUser.department ?: "Operations Command",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Exit Admin / Return to Citizen Dashboard
                        Button(
                            onClick = onLogout,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF334155).copy(alpha = 0.85f),
                                contentColor = Color(0xFFF1F5F9)
                            ),
                            shape = GlassPillShape,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("admin_logout_button")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Exit Admin",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Logout", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Command Portal Tabs: Triage Queue vs City Analytics vs Department Directory
            TabRow(
                selectedTabIndex = selectedAdminSection,
                containerColor = Color(0xFF1E293B).copy(alpha = 0.85f),
                contentColor = Color(0xFF38BDF8),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .clip(GlassPillShape)
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f), GlassPillShape),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedAdminSection]),
                        color = Color(0xFF38BDF8)
                    )
                }
            ) {
                Tab(
                    selected = selectedAdminSection == 0,
                    onClick = { selectedAdminSection = 0 },
                    text = {
                        Text(
                            text = "Triage Queue (${allRawIssues.count { it.status == "PENDING_REVIEW" || it.status == "SUBMITTED" }})",
                            fontWeight = if (selectedAdminSection == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedAdminSection == 0) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    }
                )
                Tab(
                    selected = selectedAdminSection == 1,
                    onClick = { selectedAdminSection = 1 },
                    text = {
                        Text(
                            text = "SLA & Analytics",
                            fontWeight = if (selectedAdminSection == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedAdminSection == 1) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    }
                )
                Tab(
                    selected = selectedAdminSection == 2,
                    onClick = { selectedAdminSection = 2 },
                    text = {
                        Text(
                            text = "Department Caseload",
                            fontWeight = if (selectedAdminSection == 2) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedAdminSection == 2) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    }
                )
            }

            when (selectedAdminSection) {
                0 -> {
                    // SECTION 0: Triage & Dispatch Queue
                    AdminTriageQueue(
                        issues = filteredIssues,
                        totalUnresolved = allRawIssues.count { it.status != "RESOLVED" && it.status != "CLOSED" },
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        selectedStatus = selectedStatusFilter,
                        onSelectStatus = { selectedStatusFilter = it },
                        onIssueClick = onIssueClick,
                        onQuickTriage = { issue ->
                            quickActionIssue = issue
                            newStatusTarget = IssueStatus.fromName(issue.status)
                            newDeptTarget = issue.assignedDepartment ?: "Public Works Department (PWD)"
                            officerAssigned = issue.assignedOfficer ?: ""
                            triageRemarks = issue.adminRemarks ?: ""
                        }
                    )
                }
                1 -> {
                    // SECTION 1: Municipal Analytics Screen View
                    AnalyticsScreen(viewModel = viewModel)
                }
                2 -> {
                    // SECTION 2: Department Roster & Caseload Directory
                    AdminDepartmentDirectory(allIssues = allRawIssues)
                }
            }
        }

        // Quick Triage Dialog for Dispatch & Status Update
        if (quickActionIssue != null) {
            val issue = quickActionIssue!!
            var isDeptExpanded by remember { mutableStateOf(false) }

            AlertDialog(
                onDismissRequest = { quickActionIssue = null },
                shape = RoundedCornerShape(20.dp),
                containerColor = Color.White,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFFB45309),
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Triage Ticket: ${issue.id}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = issue.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Text(
                            text = "Status Workflow:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(IssueStatus.entries) { stat ->
                                val isSel = newStatusTarget == stat
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) Color(0xFF0284C7) else Color(0xFFF1F5F9),
                                    modifier = Modifier.clickable { newStatusTarget = stat }
                                ) {
                                    Text(
                                        text = stat.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) Color.White else Color(0xFF334155),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        // Department assignment
                        Text(
                            text = "Assign Department:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )

                        ExposedDropdownMenuBox(
                            expanded = isDeptExpanded,
                            onExpandedChange = { isDeptExpanded = !isDeptExpanded }
                        ) {
                            OutlinedTextField(
                                value = newDeptTarget,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDeptExpanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isDeptExpanded,
                                onDismissRequest = { isDeptExpanded = false }
                            ) {
                                departments.filter { it != "All Departments" }.forEach { dept ->
                                    DropdownMenuItem(
                                        text = { Text(dept, fontSize = 12.sp) },
                                        onClick = {
                                            newDeptTarget = dept
                                            isDeptExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Officer Assignment
                        OutlinedTextField(
                            value = officerAssigned,
                            onValueChange = { officerAssigned = it },
                            label = { Text("Lead Field Officer") },
                            placeholder = { Text("e.g. Officer James Vance") },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Remarks
                        OutlinedTextField(
                            value = triageRemarks,
                            onValueChange = { triageRemarks = it },
                            label = { Text("Official Action Note / Log") },
                            placeholder = { Text("e.g. Crew dispatched for pothole patch work.") },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.adminUpdateStatus(
                                issueId = issue.id,
                                newStatus = newStatusTarget,
                                remarks = triageRemarks.ifBlank { null },
                                resolutionPhotoUri = null
                            )
                            viewModel.adminAssignDepartment(
                                issueId = issue.id,
                                department = newDeptTarget,
                                officer = officerAssigned.ifBlank { null },
                                priority = IssuePriority.fromName(issue.priority)
                            )
                            quickActionIssue = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Apply Triage & Dispatch", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { quickActionIssue = null }) {
                        Text("Cancel", color = Color(0xFF64748B))
                    }
                }
            )
        }
    }
}

@Composable
private fun AdminTriageQueue(
    issues: List<CivicIssueEntity>,
    totalUnresolved: Int,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedStatus: String?,
    onSelectStatus: (String?) -> Unit,
    onIssueClick: (String) -> Unit,
    onQuickTriage: (CivicIssueEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("admin_triage_queue"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // KPI Triage Banner
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CivicKpiCard(
                    title = "Pending Triage",
                    value = "$totalUnresolved",
                    subtitle = "Tickets awaiting review",
                    accentColor = Color(0xFFB45309),
                    modifier = Modifier.weight(1f)
                )
                CivicKpiCard(
                    title = "Active Filter",
                    value = "${issues.size}",
                    subtitle = "Complaints matching view",
                    accentColor = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Filter ticket #, description, or citizen...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF0284C7)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_search_input"),
                shape = GlassPillShape,
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White.copy(alpha = 0.9f)
                )
            )
        }

        // Status Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedStatus == null || selectedStatus == "ALL",
                        onClick = { onSelectStatus("ALL") },
                        label = { Text("All Statuses") },
                        shape = GlassPillShape
                    )
                }
                items(IssueStatus.entries) { stat ->
                    val isSel = selectedStatus == stat.name
                    FilterChip(
                        selected = isSel,
                        onClick = { onSelectStatus(if (isSel) "ALL" else stat.name) },
                        label = { Text(stat.label) },
                        shape = GlassPillShape
                    )
                }
            }
        }

        // Issues Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dispatch Queue (${issues.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFEF3C7)
                ) {
                    Text(
                        text = "Authorized Admin Role",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Issues List with Triage Buttons
        if (issues.isEmpty()) {
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.AssignmentTurnedIn,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No pending tickets in this view",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "All reported civic issues in this filter have been triaged.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }
        } else {
            items(issues, key = { it.id }) { issue ->
                AdminIssueTicketCard(
                    issue = issue,
                    onClick = { onIssueClick(issue.id) },
                    onQuickTriage = { onQuickTriage(issue) }
                )
            }
        }
    }
}

@Composable
fun AdminIssueTicketCard(
    issue: CivicIssueEntity,
    onClick: () -> Unit,
    onQuickTriage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val category = IssueCategory.fromId(issue.category)
    val status = IssueStatus.fromName(issue.status)
    val priority = IssuePriority.fromName(issue.priority)
    val sdf = remember(issue.createdAt) { SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()) }

    LiquidGlassCard(
        shape = GlassCardShape,
        backgroundColor = Color.White.copy(alpha = 0.88f),
        tintColor = Color(0xFFF0F9FF).copy(alpha = 0.60f),
        borderWidth = 1.25.dp,
        elevation = 3.dp,
        onClick = onClick,
        contentPadding = PaddingValues(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("admin_issue_ticket_${issue.id}")
    ) {
        Column {
            // Header: Category, ID, Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                category.icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = issue.id,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = category.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PriorityBadge(priority = priority)
                    StatusBadge(status = status)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Description
            Text(
                text = issue.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = issue.description,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF475569),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata: Citizen, Address & Department
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = issue.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Citizen: ${if (issue.isAnonymous) "Anonymous" else issue.citizenName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B),
                    fontSize = 10.sp
                )
                Text(
                    text = "Dept: ${issue.assignedDepartment ?: "Unassigned"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF0369A1),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(10.dp))

            // Action row: View details or Fast Triage
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onClick,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Audit Details", fontSize = 12.sp)
                }

                Button(
                    onClick = onQuickTriage,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("admin_quick_triage_${issue.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Triage Ticket", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AdminDepartmentDirectory(allIssues: List<CivicIssueEntity>) {
    val deptStats = listOf(
        Triple("Public Works Department (PWD)", "Roads, Bridges, Potholes", 92),
        Triple("Waste Management Dept", "Garbage collection, Dump cleanup", 96),
        Triple("Water Supply & Sewerage", "Water leaks, Drainage blockages", 88),
        Triple("Municipal Electricity Board", "Street lighting, Transformer repairs", 90),
        Triple("Parks & Greenery Dept", "Tree maintenance, Public gardens", 94),
        Triple("Traffic Engineering Dept", "Traffic signals, Road markings", 85)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("admin_department_directory"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Municipal Department Operations Directory",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Track active caseload distribution and response metrics per agency.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF64748B)
            )
        }

        items(deptStats) { (deptName, scope, sla) ->
            val deptIssues = allIssues.filter { it.assignedDepartment?.contains(deptName.split(" ").first(), ignoreCase = true) == true }
            val resolvedCount = deptIssues.count { it.status == "RESOLVED" || it.status == "CLOSED" }

            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.88f),
                tintColor = Color(0xFFF0F9FF).copy(alpha = 0.60f),
                elevation = 3.dp,
                contentPadding = PaddingValues(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = deptName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = scope,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B),
                                fontSize = 11.sp
                            )
                        }

                        Surface(
                            shape = GlassPillShape,
                            color = Color(0xFFDCFCE7)
                        ) {
                            Text(
                                text = "$sla% SLA Target",
                                color = Color(0xFF16A34A),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Assigned Tickets: ${deptIssues.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF334155)
                        )
                        Text(
                            text = "Resolved: $resolvedCount",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF16A34A)
                        )
                        Text(
                            text = "Pending: ${deptIssues.size - resolvedCount}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFD97706)
                        )
                    }
                }
            }
        }
    }
}
