package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.CivicViewModel
import com.example.ui.components.CivicBarChart
import com.example.ui.components.CivicKpiCard
import com.example.ui.components.CivicStatusDonutChart
import com.example.ui.components.GlassCardShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.LiquidGlassCard

@Composable
fun AnalyticsScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val analytics by viewModel.analytics.collectAsStateWithLifecycle()
    var exportSuccessMessage by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "Civic Insights & Analytics",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Real-time metrics, SLA performance, and category distribution across all municipal sectors.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Top KPI Cards Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CivicKpiCard(
                    title = "Resolution Rate",
                    value = "${analytics.resolutionRatePercent}%",
                    subtitle = "${analytics.resolvedComplaints} of ${analytics.totalComplaints} closed",
                    accentColor = Color(0xFF16A34A),
                    modifier = Modifier.weight(1f)
                )

                CivicKpiCard(
                    title = "Avg SLA Time",
                    value = "${analytics.avgResolutionDays}d",
                    subtitle = "Average days to resolve",
                    accentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CivicKpiCard(
                    title = "In Progress",
                    value = "${analytics.inProgressComplaints}",
                    subtitle = "Active field work crews",
                    accentColor = Color(0xFFEA580C),
                    modifier = Modifier.weight(1f)
                )

                CivicKpiCard(
                    title = "Pending Triage",
                    value = "${analytics.pendingReviewComplaints}",
                    subtitle = "Awaiting review/assign",
                    accentColor = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Status Breakdown Donut Chart
        item {
            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.88f),
                tintColor = Color(0xFFF0F9FF).copy(alpha = 0.60f),
                elevation = 3.dp,
                contentPadding = PaddingValues(16.dp)
            ) {
                Column {
                    Text(
                        text = "STATUS BREAKDOWN",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    CivicStatusDonutChart(statusCounts = analytics.statusCounts)
                }
            }
        }

        // Category Distribution Bar Chart
        item {
            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.88f),
                tintColor = Color(0xFFF0F9FF).copy(alpha = 0.60f),
                elevation = 3.dp,
                contentPadding = PaddingValues(16.dp)
            ) {
                Column {
                    Text(
                        text = "ISSUES BY CATEGORY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    CivicBarChart(
                        data = analytics.categoryCounts,
                        barColor = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Municipal Department Performance
        item {
            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.88f),
                tintColor = Color(0xFFF0F9FF).copy(alpha = 0.60f),
                elevation = 3.dp,
                contentPadding = PaddingValues(16.dp)
            ) {
                Column {
                    Text(
                        text = "DEPARTMENT CASELOAD",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val deptStats = listOf(
                        Triple("Public Works Dept (PWD)", 92, "1.8d avg"),
                        Triple("Waste Management Dept", 96, "0.9d avg"),
                        Triple("Water Supply & Sewerage", 88, "2.1d avg"),
                        Triple("Municipal Electricity Board", 90, "1.4d avg"),
                        Triple("Parks & Greenery Dept", 94, "1.5d avg"),
                        Triple("Traffic Engineering Dept", 85, "2.7d avg")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        deptStats.forEach { (dept, slaRate, avgTime) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = dept,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Resolution rate: $slaRate% • $avgTime",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Surface(
                                    shape = GlassPillShape,
                                    color = Color(0xFFDCFCE7)
                                ) {
                                    Text(
                                        text = "$slaRate% SLA",
                                        color = Color(0xFF16A34A),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Export Report Button
        item {
            Button(
                onClick = { exportSuccessMessage = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = GlassPillShape
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export Civic Resolution Report (CSV/PDF)")
            }

            if (exportSuccessMessage) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Report generated and downloaded to device cache.",
                    color = Color(0xFF16A34A),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
