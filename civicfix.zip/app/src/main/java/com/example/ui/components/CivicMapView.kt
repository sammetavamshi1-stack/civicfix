package com.example.ui.components

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Satellite
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.CivicIssueEntity
import com.example.model.IssueCategory
import com.example.model.IssueStatus
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.CameraPositionState
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

enum class CivicMapDisplayMode(val label: String, val mapType: MapType?) {
    NORMAL("Street", MapType.NORMAL),
    HYBRID("Satellite", MapType.HYBRID),
    TERRAIN("Terrain", MapType.TERRAIN),
    OFFLINE_VECTOR("Offline", null)
}

/**
 * Interactive Google Maps SDK view for exploring and pinning municipal civic issues.
 * Supports Google Maps street/satellite/terrain views with interactive markers and location pinning,
 * as well as an offline procedural vector cartography mode.
 */
@Composable
fun CivicMapView(
    issues: List<CivicIssueEntity>,
    selectedIssue: CivicIssueEntity?,
    onIssueSelected: (CivicIssueEntity?) -> Unit,
    isSelectionMode: Boolean = false,
    selectedCoordinates: Pair<Double, Double>? = null,
    onCoordinatesSelected: ((Double, Double) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Default civic anchor (San Francisco Civic Center: 37.7749, -122.4194)
    val defaultCenter = LatLng(37.7749, -122.4194)

    val initialCenter = remember(selectedCoordinates, issues) {
        when {
            selectedCoordinates != null -> LatLng(selectedCoordinates.first, selectedCoordinates.second)
            issues.isNotEmpty() -> LatLng(issues.first().latitude, issues.first().longitude)
            else -> defaultCenter
        }
    }

    // Google Play Services availability check
    val isGooglePlayServicesAvailable = remember {
        try {
            val availability = GoogleApiAvailability.getInstance()
            availability.isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
        } catch (_: Exception) {
            true
        }
    }

    var displayMode by remember {
        mutableStateOf(
            if (isGooglePlayServicesAvailable) CivicMapDisplayMode.NORMAL
            else CivicMapDisplayMode.OFFLINE_VECTOR
        )
    }

    var showLayerSelector by remember { mutableStateOf(false) }

    // Google Map Camera State
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(
            initialCenter,
            if (isSelectionMode) 15.5f else 14f
        )
    }

    // Animate camera when selected issue changes
    LaunchedEffect(selectedIssue) {
        if (selectedIssue != null) {
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLngZoom(
                    LatLng(selectedIssue.latitude, selectedIssue.longitude),
                    16.2f
                ),
                durationMs = 700
            )
        }
    }

    // Animate camera when pinned coordinates update in selection mode
    LaunchedEffect(selectedCoordinates) {
        if (isSelectionMode && selectedCoordinates != null) {
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLng(
                    LatLng(selectedCoordinates.first, selectedCoordinates.second)
                ),
                durationMs = 500
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("civic_map_container")
    ) {
        val activeMapType = displayMode.mapType
        if (activeMapType != null) {
            // Google Maps SDK interactive surface
            GoogleMap(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("google_map_view"),
                cameraPositionState = cameraPositionState,
                properties = remember(activeMapType) {
                    MapProperties(
                        mapType = activeMapType,
                        isMyLocationEnabled = false
                    )
                },
                uiSettings = remember {
                    MapUiSettings(
                        zoomControlsEnabled = false,
                        myLocationButtonEnabled = false,
                        compassEnabled = true,
                        mapToolbarEnabled = true,
                        rotationGesturesEnabled = true,
                        tiltGesturesEnabled = true,
                        scrollGesturesEnabled = true,
                        zoomGesturesEnabled = true
                    )
                },
                onMapClick = { latLng ->
                    if (isSelectionMode) {
                        onCoordinatesSelected?.invoke(latLng.latitude, latLng.longitude)
                    } else {
                        onIssueSelected(null)
                    }
                }
            ) {
                // Render civic issue markers
                issues.forEach { issue ->
                    val markerPos = LatLng(issue.latitude, issue.longitude)
                    val markerState = rememberMarkerState(key = issue.id, position = markerPos)
                    val statusHue = getMarkerHueForStatus(issue.status)
                    val isSelected = issue.id == selectedIssue?.id

                    Marker(
                        state = markerState,
                        title = "${issue.category}: ${issue.title}",
                        snippet = "${issue.status} • ${issue.address} • 👍 ${issue.upvotes}",
                        icon = BitmapDescriptorFactory.defaultMarker(statusHue),
                        zIndex = if (isSelected) 2.0f else 1.0f,
                        onClick = {
                            onIssueSelected(issue)
                            true
                        }
                    )
                }

                // Render draggable/tappable pin marker in selection mode
                if (isSelectionMode && selectedCoordinates != null) {
                    val pinPos = LatLng(selectedCoordinates.first, selectedCoordinates.second)
                    val pinMarkerState = rememberMarkerState(key = "selected_pin", position = pinPos)

                    LaunchedEffect(pinPos) {
                        pinMarkerState.position = pinPos
                    }

                    Marker(
                        state = pinMarkerState,
                        title = "Pinned Location",
                        snippet = "Tap anywhere on the map to relocate",
                        draggable = true,
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE),
                        zIndex = 5.0f
                    )
                }
            }
        } else {
            // High-performance Offline Vector Cartography
            OfflineVectorCivicMap(
                issues = issues,
                selectedIssue = selectedIssue,
                onIssueSelected = onIssueSelected,
                isSelectionMode = isSelectionMode,
                selectedCoordinates = selectedCoordinates,
                onCoordinatesSelected = onCoordinatesSelected
            )
        }

        // Selection Mode Prompt Banner
        if (isSelectionMode) {
            Surface(
                shape = GlassPillShape,
                color = Color.White.copy(alpha = 0.92f),
                shadowElevation = 3.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
                    .liquidGlass(
                        shape = GlassPillShape,
                        backgroundColor = Color.White.copy(alpha = 0.92f),
                        borderColorStart = Color(0xFF0284C7),
                        borderColorEnd = Color(0xFF38BDF8),
                        borderWidth = 1.35.dp,
                        elevation = 3.dp
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.PinDrop,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (selectedCoordinates != null) {
                            "Pinned: ${"%.4f".format(selectedCoordinates.first)}, ${"%.4f".format(selectedCoordinates.second)}"
                        } else {
                            "Tap map to drop complaint pin"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Floating Map Controls (Layer switch, Zoom +, Zoom -, Recenter)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = if (isSelectionMode) 52.dp else 16.dp, end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Map Layer Selector Button
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.90f),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .liquidGlass(
                        shape = CircleShape,
                        backgroundColor = Color.White.copy(alpha = 0.90f),
                        borderColorStart = Color(0xFFCBD5E1),
                        borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                        borderWidth = 1.35.dp,
                        elevation = 4.dp
                    )
                    .clickable { showLayerSelector = !showLayerSelector }
                    .testTag("map_layers_button")
            ) {
                Box(
                    modifier = Modifier.size(42.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Layers,
                        contentDescription = "Map Layers",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Zoom Controls
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.90f),
                shadowElevation = 4.dp,
                modifier = Modifier.liquidGlass(
                    shape = RoundedCornerShape(14.dp),
                    backgroundColor = Color.White.copy(alpha = 0.90f),
                    borderColorStart = Color(0xFFCBD5E1),
                    borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                    borderWidth = 1.35.dp,
                    elevation = 4.dp
                )
            ) {
                Column {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                cameraPositionState.animate(CameraUpdateFactory.zoomIn())
                            }
                        },
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom In")
                    }
                    Box(
                        modifier = Modifier
                            .width(42.dp)
                            .height(1.dp)
                            .background(Color(0xFFCBD5E1))
                    )
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                cameraPositionState.animate(CameraUpdateFactory.zoomOut())
                            }
                        },
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
                    }
                }
            }

            // Recenter Button
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.90f),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .liquidGlass(
                        shape = CircleShape,
                        backgroundColor = Color.White.copy(alpha = 0.90f),
                        borderColorStart = Color(0xFFCBD5E1),
                        borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                        borderWidth = 1.35.dp,
                        elevation = 4.dp
                    )
                    .clickable {
                        coroutineScope.launch {
                            val target = when {
                                selectedIssue != null -> LatLng(selectedIssue.latitude, selectedIssue.longitude)
                                selectedCoordinates != null -> LatLng(selectedCoordinates.first, selectedCoordinates.second)
                                issues.isNotEmpty() -> LatLng(issues.first().latitude, issues.first().longitude)
                                else -> defaultCenter
                            }
                            cameraPositionState.animate(
                                CameraUpdateFactory.newLatLngZoom(target, 14.5f)
                            )
                        }
                    }
                    .testTag("map_recenter_button")
            ) {
                Box(
                    modifier = Modifier.size(42.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.MyLocation,
                        contentDescription = "Recenter Map",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Expandable Layer Switcher Card
        AnimatedVisibility(
            visible = showLayerSelector,
            enter = fadeIn() + slideInVertically { -it / 3 },
            exit = fadeOut() + slideOutVertically { -it / 3 },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = if (isSelectionMode) 52.dp else 16.dp, end = 68.dp)
        ) {
            LiquidGlassCard(
                shape = GlassCardShape,
                backgroundColor = Color.White.copy(alpha = 0.95f),
                tintColor = Color(0xFFE0F2FE).copy(alpha = 0.45f),
                borderColorStart = Color(0xFFCBD5E1),
                borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.5f),
                borderWidth = 1.35.dp,
                elevation = 6.dp
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Map Layer",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )

                    CivicMapDisplayMode.entries.forEach { mode ->
                        val isSel = displayMode == mode
                        Surface(
                            shape = GlassPillShape,
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    displayMode = mode
                                    showLayerSelector = false
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    when (mode) {
                                        CivicMapDisplayMode.NORMAL -> Icons.Default.Map
                                        CivicMapDisplayMode.HYBRID -> Icons.Default.Satellite
                                        CivicMapDisplayMode.TERRAIN -> Icons.Default.Terrain
                                        CivicMapDisplayMode.OFFLINE_VECTOR -> Icons.Default.Place
                                    },
                                    contentDescription = null,
                                    tint = if (isSel) MaterialTheme.colorScheme.primary else Color(0xFF64748B),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFF334155)
                                )
                                if (isSel) {
                                    Spacer(modifier = Modifier.weight(1f))
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Map Legend chip (Bottom-left corner)
        if (!isSelectionMode) {
            Surface(
                shape = GlassPillShape,
                color = Color.White.copy(alpha = 0.90f),
                shadowElevation = 3.dp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 16.dp, bottom = if (selectedIssue != null) 176.dp else 16.dp)
                    .liquidGlass(
                        shape = GlassPillShape,
                        backgroundColor = Color.White.copy(alpha = 0.90f),
                        borderColorStart = Color(0xFFCBD5E1),
                        borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                        borderWidth = 1.35.dp,
                        elevation = 3.dp
                    )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    LegendDot(color = Color(0xFF8B5CF6), label = "Submitted")
                    LegendDot(color = Color(0xFFF97316), label = "In Progress")
                    LegendDot(color = Color(0xFF22C55E), label = "Resolved")
                }
            }
        }

        // Selected Issue Bottom Preview Card
        AnimatedVisibility(
            visible = selectedIssue != null && !isSelectionMode,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            selectedIssue?.let { issue ->
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.92f),
                    tintColor = Color(0xFFF0F9FF).copy(alpha = 0.5f),
                    borderColorStart = Color(0xFFCBD5E1),
                    borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.50f),
                    borderWidth = 1.35.dp,
                    elevation = 6.dp,
                    onClick = { onIssueSelected(issue) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = issue.id,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            StatusBadge(status = IssueStatus.fromName(issue.status))
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = issue.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = issue.address,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B),
                                maxLines = 1
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = issue.assignedDepartment ?: "Pending Dispatch",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "View tracking details →",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Returns Google Maps marker hue based on civic issue status.
 */
private fun getMarkerHueForStatus(statusStr: String): Float {
    return when (statusStr.uppercase()) {
        "SUBMITTED" -> BitmapDescriptorFactory.HUE_VIOLET
        "IN_PROGRESS" -> BitmapDescriptorFactory.HUE_ORANGE
        "RESOLVED" -> BitmapDescriptorFactory.HUE_GREEN
        "REJECTED" -> BitmapDescriptorFactory.HUE_RED
        else -> BitmapDescriptorFactory.HUE_AZURE
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 11.sp, color = Color(0xFF334155), fontWeight = FontWeight.Medium)
    }
}

/**
 * Offline vector cartography fallback engine.
 */
@Composable
private fun OfflineVectorCivicMap(
    issues: List<CivicIssueEntity>,
    selectedIssue: CivicIssueEntity?,
    onIssueSelected: (CivicIssueEntity?) -> Unit,
    isSelectionMode: Boolean,
    selectedCoordinates: Pair<Double, Double>?,
    onCoordinatesSelected: ((Double, Double) -> Unit)?
) {
    val centerLat = 37.7750
    val centerLon = -122.4180
    val latSpan = 0.025
    val lonSpan = 0.025

    var zoomLevel by remember { mutableFloatStateOf(1.0f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 26f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        fun toScreenOffset(lat: Double, lon: Double): Offset {
            val normX = ((lon - (centerLon - lonSpan / 2)) / lonSpan).toFloat()
            val normY = (1f - ((lat - (centerLat - latSpan / 2)) / latSpan)).toFloat()
            val screenX = (normX * width * zoomLevel) + panOffsetX
            val screenY = (normY * height * zoomLevel) + panOffsetY
            return Offset(screenX, screenY)
        }

        fun toGeoCoordinates(screenOffset: Offset): Pair<Double, Double> {
            val adjustedX = (screenOffset.x - panOffsetX) / (width * zoomLevel)
            val adjustedY = (screenOffset.y - panOffsetY) / (height * zoomLevel)
            val lon = (adjustedX * lonSpan) + (centerLon - lonSpan / 2)
            val lat = ((1f - adjustedY) * latSpan) + (centerLat - latSpan / 2)
            return Pair(lat.toDouble(), lon.toDouble())
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        panOffsetX += dragAmount.x
                        panOffsetY += dragAmount.y
                    }
                }
                .pointerInput(isSelectionMode, issues) {
                    detectTapGestures { tapOffset ->
                        if (isSelectionMode) {
                            val (lat, lon) = toGeoCoordinates(tapOffset)
                            onCoordinatesSelected?.invoke(lat, lon)
                        } else {
                            var found: CivicIssueEntity? = null
                            for (issue in issues) {
                                val markerPos = toScreenOffset(issue.latitude, issue.longitude)
                                val dist = (markerPos - tapOffset).getDistance()
                                if (dist < 48f) {
                                    found = issue
                                    break
                                }
                            }
                            onIssueSelected(found)
                        }
                    }
                }
        ) {
            drawCivicCityMap(
                width = size.width,
                height = size.height,
                zoom = zoomLevel,
                offsetX = panOffsetX,
                offsetY = panOffsetY
            )

            issues.forEach { issue ->
                val pos = toScreenOffset(issue.latitude, issue.longitude)
                val status = IssueStatus.fromName(issue.status)
                val isSelected = issue.id == selectedIssue?.id

                if (isSelected || issue.priority == "CRITICAL") {
                    drawCircle(
                        color = status.color.copy(alpha = 0.25f),
                        radius = pulseRadius * zoomLevel,
                        center = pos
                    )
                }

                drawCircle(
                    color = Color.Black.copy(alpha = 0.35f),
                    radius = if (isSelected) 18f else 14f,
                    center = pos + Offset(2f, 3f)
                )
                drawCircle(
                    color = Color.White,
                    radius = if (isSelected) 17f else 13f,
                    center = pos
                )
                drawCircle(
                    color = status.color,
                    radius = if (isSelected) 14f else 10f,
                    center = pos
                )
            }

            if (isSelectionMode && selectedCoordinates != null) {
                val pinPos = toScreenOffset(selectedCoordinates.first, selectedCoordinates.second)
                drawCircle(
                    color = Color(0xFF0284C7).copy(alpha = 0.3f),
                    radius = 28f,
                    center = pinPos
                )
                drawCircle(
                    color = Color(0xFF0284C7),
                    radius = 12f,
                    center = pinPos
                )
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = pinPos
                )
            }
        }
    }
}

/**
 * Procedural vector cartography rendering roads, municipal parks, city waterways, and blocks.
 */
private fun DrawScope.drawCivicCityMap(
    width: Float,
    height: Float,
    zoom: Float,
    offsetX: Float,
    offsetY: Float
) {
    drawRect(color = Color(0xFFF1F5F9))

    val waterPath = Path().apply {
        moveTo(0f + offsetX, height * 0.75f * zoom + offsetY)
        cubicTo(
            width * 0.3f * zoom + offsetX, height * 0.85f * zoom + offsetY,
            width * 0.7f * zoom + offsetX, height * 0.65f * zoom + offsetY,
            width * zoom + offsetX, height * 0.72f * zoom + offsetY
        )
        lineTo(width * zoom + offsetX, height * zoom + offsetY)
        lineTo(0f + offsetX, height * zoom + offsetY)
        close()
    }
    drawPath(waterPath, color = Color(0xFFBAE6FD))

    drawRoundRect(
        color = Color(0xFFDCFCE7),
        topLeft = Offset(width * 0.15f * zoom + offsetX, height * 0.18f * zoom + offsetY),
        size = Size(width * 0.28f * zoom, height * 0.22f * zoom),
        cornerRadius = CornerRadius(16f, 16f)
    )

    drawRoundRect(
        color = Color(0xFFDCFCE7),
        topLeft = Offset(width * 0.62f * zoom + offsetX, height * 0.45f * zoom + offsetY),
        size = Size(width * 0.25f * zoom, height * 0.18f * zoom),
        cornerRadius = CornerRadius(16f, 16f)
    )

    val minorRoadPaint = Color(0xFFFFFFFF)
    val minorStrokeWidth = 5f * zoom

    for (i in 1..8) {
        val y = (height * (i / 9f) * zoom) + offsetY
        drawLine(
            color = minorRoadPaint,
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = minorStrokeWidth
        )
    }

    for (i in 1..8) {
        val x = (width * (i / 9f) * zoom) + offsetX
        drawLine(
            color = minorRoadPaint,
            start = Offset(x, 0f),
            end = Offset(x, height),
            strokeWidth = minorStrokeWidth
        )
    }

    val majorRoadPaint = Color(0xFFFFEDD5)
    val majorStrokeWidth = 10f * zoom

    drawLine(
        color = majorRoadPaint,
        start = Offset(0f + offsetX, height * 0.2f * zoom + offsetY),
        end = Offset(width * zoom + offsetX, height * 0.8f * zoom + offsetY),
        strokeWidth = majorStrokeWidth
    )

    drawLine(
        color = majorRoadPaint,
        start = Offset(width * 0.5f * zoom + offsetX, 0f),
        end = Offset(width * 0.5f * zoom + offsetX, height),
        strokeWidth = majorStrokeWidth
    )

    drawLine(
        color = majorRoadPaint,
        start = Offset(0f, height * 0.5f * zoom + offsetY),
        end = Offset(width, height * 0.5f * zoom + offsetY),
        strokeWidth = majorStrokeWidth
    )
}
