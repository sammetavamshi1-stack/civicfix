package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IssuePriority
import com.example.model.IssueStatus

@Composable
fun StatusBadge(
    status: IssueStatus,
    modifier: Modifier = Modifier
) {
    val icon = when (status) {
        IssueStatus.SUBMITTED -> Icons.Default.HourglassTop
        IssueStatus.UNDER_REVIEW -> Icons.Default.Sync
        IssueStatus.ASSIGNED -> Icons.Default.Sync
        IssueStatus.IN_PROGRESS -> Icons.Default.Sync
        IssueStatus.RESOLVED -> Icons.Default.CheckCircle
        IssueStatus.CLOSED -> Icons.Default.CheckCircle
    }

    Box(
        modifier = modifier
            .shadow(1.dp, GlassPillShape, ambientColor = status.color.copy(alpha = 0.2f))
            .clip(GlassPillShape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.90f),
                        status.color.copy(alpha = 0.15f)
                    )
                )
            )
            .border(
                width = 1.25.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        status.color.copy(alpha = 0.85f),
                        status.color.copy(alpha = 0.50f),
                        Color(0xFF94A3B8)
                    )
                ),
                shape = GlassPillShape
            )
            .semantics {
                contentDescription = "Status: ${status.label}"
            }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(status.color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = status.label,
                color = status.color,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun PriorityBadge(
    priority: IssuePriority,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(1.dp, GlassPillShape, ambientColor = priority.color.copy(alpha = 0.2f))
            .clip(GlassPillShape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.90f),
                        priority.color.copy(alpha = 0.12f)
                    )
                )
            )
            .border(
                width = 1.25.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        priority.color.copy(alpha = 0.85f),
                        priority.color.copy(alpha = 0.50f),
                        Color(0xFF94A3B8)
                    )
                ),
                shape = GlassPillShape
            )
            .semantics {
                contentDescription = "Priority: ${priority.label}"
            }
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (priority == IssuePriority.CRITICAL || priority == IssuePriority.HIGH) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = priority.color,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
            }
            Text(
                text = priority.label,
                color = priority.color,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun SyncStatusIndicator(
    isSynced: Boolean,
    modifier: Modifier = Modifier
) {
    val (color, text, icon) = if (isSynced) {
        Triple(Color(0xFF16A34A), "Synced", Icons.Default.CloudDone)
    } else {
        Triple(Color(0xFFD97706), "Pending Sync", Icons.Default.CloudOff)
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.semantics {
            contentDescription = "Data status: $text"
        }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

