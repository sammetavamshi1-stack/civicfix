package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = CivicPrimaryDark,
    onPrimary = CivicOnPrimaryDark,
    background = CivicBackgroundDark,
    onBackground = CivicOnBackgroundDark,
    surface = CivicSurfaceDark,
    onSurface = CivicOnSurfaceDark
  )

private val LightColorScheme =
  lightColorScheme(
    primary = CivicPrimary,
    onPrimary = CivicOnPrimary,
    primaryContainer = CivicPrimaryContainer,
    onPrimaryContainer = CivicOnPrimaryContainer,
    secondary = CivicSecondary,
    onSecondary = CivicOnSecondary,
    secondaryContainer = CivicSecondaryContainer,
    onSecondaryContainer = CivicOnSecondaryContainer,
    tertiary = CivicTertiary,
    onTertiary = CivicOnTertiary,
    tertiaryContainer = CivicTertiaryContainer,
    onTertiaryContainer = CivicOnTertiaryContainer,
    background = CivicBackground,
    onBackground = CivicOnBackground,
    surface = CivicSurface,
    onSurface = CivicOnSurface,
    surfaceVariant = CivicSurfaceVariant,
    onSurfaceVariant = CivicOnSurfaceVariant,
    outline = CivicOutline,
    outlineVariant = CivicOutlineVariant,
    error = CivicError,
    onError = CivicOnError,
    errorContainer = CivicErrorContainer,
    onErrorContainer = CivicOnErrorContainer
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

