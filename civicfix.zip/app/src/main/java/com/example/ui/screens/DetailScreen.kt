package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.AuditLogEntity
import com.example.data.CivicIssueEntity
import com.example.model.DepartmentOfficers
import com.example.model.IssueCategory
import com.example.model.IssuePriority
import com.example.model.IssueStatus
import com.example.model.MunicipalDepartments
import com.example.model.UserRole
import com.example.ui.CivicViewModel
import com.example.ui.components.GlassCardShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.GlassTopBarShape
import com.example.ui.components.LiquidAmbientCanvas
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.liquidGlass
import com.example.ui.components.PriorityBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.SyncStatusIndicator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    issueId: String,
    viewModel: CivicViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(issueId) {
        viewModel.selectIssue(issueId)
    }

    val allIssues by viewModel.rawIssues.collectAsStateWithLifecycle()
    val issue = allIssues.find { it.id == issueId }
    val auditLogs by viewModel.selectedIssueLogs.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var showStatusDialog by remember { mutableStateOf(false) }
    var showAssignDialog by remember { mutableStateOf(false) }

    if (issue == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Issue not found or was removed.")
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onBack) { Text("Go Back") }
            }
        }
        return
    }

    val category = IssueCategory.fromId(issue.category)
    val status = IssueStatus.fromName(issue.status)
    val priority = IssuePriority.fromName(issue.priority)
    val sdf = remember { SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()) }

    Box(modifier = modifier.fillMaxSize().testTag("issue_detail_screen")) {
        LiquidAmbientCanvas()

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    modifier = Modifier.liquidGlass(
                        shape = GlassTopBarShape,
                        backgroundColor = Color.White.copy(alpha = 0.88f),
                        tintColor = Color(0xFFF0F9FF).copy(alpha = 0.6f),
                        borderColorStart = Color(0xFFCBD5E1),
                        borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                        borderWidth = 1.35.dp,
                        elevation = 4.dp
                    ),
                    title = {
                        Column {
                            Text(
                                text = issue.id,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = category.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to complaints"
                            )
                        }
                    },
                    actions = {
                        StatusBadge(status = status, modifier = Modifier.padding(end = 16.dp))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Priority and Upvote Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PriorityBadge(priority = priority)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!issue.isSynced) {
                                SyncStatusIndicator(isSynced = false)
                                Spacer(modifier = Modifier.width(10.dp))
                            }
                            Surface(
                                shape = GlassPillShape,
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                modifier = Modifier
                                    .liquidGlass(
                                        shape = GlassPillShape,
                                        backgroundColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                        borderColorStart = Color(0xFF94A3B8),
                                        borderColorEnd = MaterialTheme.colorScheme.primary,
                                        borderWidth = 1.25.dp,
                                        elevation = 1.dp
                                    )
                                    .clickable { viewModel.upvoteIssue(issue.id) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ThumbUp,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${issue.upvotes} Upvotes",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }

            // Issue Title & Description Card
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    tintColor = Color(0xFFF0F9FF).copy(alpha = 0.65f),
                    borderWidth = 1.25.dp,
                    elevation = 3.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = issue.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = issue.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = issue.address,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (issue.isAnonymous) "Reported Anonymously (Identity Protected)" else "Reported by ${issue.citizenName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
            }

            // Status Timeline Stepper
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    tintColor = Color(0xFFF0F9FF).copy(alpha = 0.65f),
                    borderWidth = 1.25.dp,
                    elevation = 3.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "STATUS RESOLUTION TRACKER",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.outline,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        val steps = listOf(
                            IssueStatus.SUBMITTED,
                            IssueStatus.UNDER_REVIEW,
                            IssueStatus.ASSIGNED,
                            IssueStatus.IN_PROGRESS,
                            IssueStatus.RESOLVED
                        )

                        val currentIdx = status.stepIndex

                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            steps.forEachIndexed { index, step ->
                                val isPassed = index <= currentIdx
                                val isCurrent = index == currentIdx

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isPassed) step.color else MaterialTheme.colorScheme.surfaceVariant
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isPassed) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.outline)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = step.label,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isPassed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                        )
                                        if (isCurrent) {
                                            Text(
                                                text = "Current State",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = step.color,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Before & After Photos Showcase
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    tintColor = Color(0xFFF0F9FF).copy(alpha = 0.65f),
                    borderWidth = 1.25.dp,
                    elevation = 3.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "PHOTO DOCUMENTATION",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Before Photo
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Before (Citizen Report)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                if (!issue.photoUri.isNullOrBlank()) {
                                    AsyncImage(
                                        model = issue.photoUri,
                                        contentDescription = "Before issue photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(120.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(120.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("No photo provided", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    }
                                }
                            }

                            // Resolution Photo
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Resolution Proof",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (issue.resolutionPhotoUri != null) Color(0xFF16A34A) else MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                if (!issue.resolutionPhotoUri.isNullOrBlank()) {
                                    AsyncImage(
                                        model = issue.resolutionPhotoUri,
                                        contentDescription = "Resolution proof photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(120.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .border(2.dp, Color(0xFF16A34A), RoundedCornerShape(14.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(120.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            if (status == IssueStatus.RESOLVED) "No proof image" else "Pending repair",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Department & Official Remarks
            item {
                LiquidGlassCard(
                    shape = GlassCardShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    tintColor = Color(0xFFF0F9FF).copy(alpha = 0.65f),
                    borderWidth = 1.25.dp,
                    elevation = 3.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "DISPATCH & MUNICIPAL REMARKS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AssignmentInd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = issue.assignedDepartment ?: "Unassigned",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Lead Officer: ${issue.assignedOfficer ?: "Pending officer dispatch"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        if (!issue.adminRemarks.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Official Action Note:",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = issue.adminRemarks,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Admin Control Panel (Visible in Admin Mode)
            if (user.role == UserRole.ADMIN) {
                item {
                    LiquidGlassCard(
                        shape = GlassCardShape,
                        backgroundColor = Color(0xFFFEF3C7).copy(alpha = 0.85f),
                        tintColor = Color(0xFFFDE68A).copy(alpha = 0.6f),
                        borderColorStart = Color.White.copy(alpha = 0.9f),
                        borderColorEnd = Color(0xFFF59E0B).copy(alpha = 0.7f),
                        borderWidth = 1.25.dp,
                        elevation = 4.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Security,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ADMIN TRIAGE & ACTION PANEL",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Authorized to update workflow state, assign departments, prioritize, and attach resolution photos.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF78350F)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = { showStatusDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                    shape = GlassPillShape,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Update Status", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = { showAssignDialog = true },
                                    shape = GlassPillShape,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AssignmentInd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Dispatch", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Audit Trail / Activity History
            item {
                Text(
                    text = "AUDIT TRAIL & HISTORY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (auditLogs.isEmpty()) {
                item {
                    Text(
                        text = "No audit log entries recorded.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            } else {
                items(auditLogs) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 4.dp)
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = log.action,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = sdf.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                            Text(
                                text = "By ${log.actor}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                            if (!log.notes.isNullOrBlank()) {
                                Text(
                                    text = log.notes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Dialog: Update Status & Resolution Photo
    if (showStatusDialog) {
        var newStatus by remember { mutableStateOf(status) }
        var remarks by remember { mutableStateOf(issue.adminRemarks ?: "") }
        var resolutionPhotoUrl by remember {
            mutableStateOf(
                issue.resolutionPhotoUri
                    ?: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600&auto=format&fit=crop&q=80"
            )
        }

        AlertDialog(
            onDismissRequest = { showStatusDialog = false },
            title = { Text("Update Ticket Status", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select new workflow stage:")
                    LazyColumn(modifier = Modifier.height(140.dp)) {
                        items(IssueStatus.entries) { st ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { newStatus = st }
                                    .padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(st.color)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = st.label,
                                    fontWeight = if (newStatus == st) FontWeight.Bold else FontWeight.Normal,
                                    color = if (newStatus == st) st.color else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Official Remarks / Crew Notes") },
                        placeholder = { Text("e.g. Repairs completed by municipal crew") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (newStatus == IssueStatus.RESOLVED || newStatus == IssueStatus.CLOSED) {
                        OutlinedTextField(
                            value = resolutionPhotoUrl,
                            onValueChange = { resolutionPhotoUrl = it },
                            label = { Text("Resolution Proof Photo URL") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminUpdateStatus(
                            issueId = issue.id,
                            newStatus = newStatus,
                            remarks = remarks.trim().ifBlank { null },
                            resolutionPhotoUri = resolutionPhotoUrl.trim().ifBlank { null }
                        )
                        showStatusDialog = false
                    }
                ) {
                    Text("Apply Update")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStatusDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog: Assign Department & Officer
    if (showAssignDialog) {
        var selectedDept by remember { mutableStateOf(issue.assignedDepartment ?: MunicipalDepartments.first()) }
        var selectedOfficer by remember { mutableStateOf(issue.assignedOfficer ?: "") }
        var selectedPrio by remember { mutableStateOf(priority) }

        val officers = DepartmentOfficers[selectedDept] ?: emptyList()

        AlertDialog(
            onDismissRequest = { showAssignDialog = false },
            title = { Text("Dispatch & Assign Department", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Department:")
                    LazyColumn(modifier = Modifier.height(100.dp)) {
                        items(MunicipalDepartments) { dept ->
                            Text(
                                text = dept,
                                fontWeight = if (selectedDept == dept) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedDept == dept) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedDept = dept
                                        selectedOfficer = (DepartmentOfficers[dept]?.firstOrNull() ?: "")
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }

                    if (officers.isNotEmpty()) {
                        Text("Assign Officer / Technician:")
                        LazyColumn(modifier = Modifier.height(60.dp)) {
                            items(officers) { officer ->
                                Text(
                                    text = officer,
                                    fontWeight = if (selectedOfficer == officer) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedOfficer == officer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedOfficer = officer }
                                        .padding(vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Text("Priority:")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IssuePriority.entries.forEach { p ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedPrio == p) p.color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable { selectedPrio = p }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    p.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedPrio == p) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedPrio == p) p.color else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminAssignDepartment(
                            issueId = issue.id,
                            department = selectedDept,
                            officer = selectedOfficer.ifBlank { null },
                            priority = selectedPrio
                        )
                        showAssignDialog = false
                    }
                ) {
                    Text("Dispatch Team")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAssignDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
