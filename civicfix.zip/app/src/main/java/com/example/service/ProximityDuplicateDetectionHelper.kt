package com.example.service

import com.example.data.CivicIssueEntity
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Result of checking a proposed civic issue against existing issues in the database.
 */
data class ProximityCheckResult(
    val hasNearbyDuplicate: Boolean,
    val nearestDistanceMeters: Double?,
    val matchingCandidates: List<ProximityCandidate>
)

data class ProximityCandidate(
    val issue: CivicIssueEntity,
    val distanceMeters: Double
)

/**
 * ProximityDuplicateDetectionHelper
 *
 * Dedicated helper service that verifies new civic issue submissions against existing
 * database entries based on precise geographical proximity (Haversine formula) and category matching
 * before final submission.
 */
class ProximityDuplicateDetectionHelper(
    private val proximityThresholdMeters: Double = 350.0
) {

    /**
     * Computes great-circle distance between two geographic coordinates in meters
     * using the standard spherical Haversine formula.
     */
    fun calculateDistanceMeters(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {
        val earthRadiusMeters = 6371000.0 // Mean radius of the Earth
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusMeters * c
    }

    /**
     * Checks an incoming draft issue against existing database issues.
     * Returns proximity candidates that match category (or within vicinity) and are within threshold.
     */
    fun checkNearbyDuplicates(
        targetLatitude: Double,
        targetLongitude: Double,
        targetCategory: String,
        existingIssues: List<CivicIssueEntity>,
        customThresholdMeters: Double? = null
    ): ProximityCheckResult {
        val threshold = customThresholdMeters ?: proximityThresholdMeters

        val candidates = existingIssues
            .filter { issue ->
                // Do not match issues that are already closed or marked as resolved more than 30 days ago
                issue.status != "CLOSED"
            }
            .mapNotNull { issue ->
                val distance = calculateDistanceMeters(
                    lat1 = targetLatitude,
                    lon1 = targetLongitude,
                    lat2 = issue.latitude,
                    lon2 = issue.longitude
                )

                // High confidence match: exact category match within threshold
                // or very close vicinity (< 100 meters) regardless of minor category variance
                val isCategoryMatch = issue.category.equals(targetCategory, ignoreCase = true)
                val isWithinDistance = distance <= threshold

                if (isWithinDistance && (isCategoryMatch || distance <= 100.0)) {
                    ProximityCandidate(issue = issue, distanceMeters = distance)
                } else {
                    null
                }
            }
            .sortedBy { it.distanceMeters }

        return ProximityCheckResult(
            hasNearbyDuplicate = candidates.isNotEmpty(),
            nearestDistanceMeters = candidates.firstOrNull()?.distanceMeters,
            matchingCandidates = candidates
        )
    }
}
