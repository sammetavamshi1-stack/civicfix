package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.UserRole
import com.example.ui.CivicViewModel
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.GlassBottomNavShape
import com.example.ui.components.GlassPillShape
import com.example.ui.components.GlassTopBarShape
import com.example.ui.components.LiquidAmbientCanvas
import com.example.ui.components.liquidGlass
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.theme.MyApplicationTheme

enum class CivicNavDestination(
    val label: String,
    val filledIcon: ImageVector,
    val outlinedIcon: ImageVector
) {
    FEED("Complaints", Icons.Filled.ListAlt, Icons.Outlined.ListAlt),
    MAP("City Map", Icons.Filled.Map, Icons.Outlined.Map),
    REPORT("Report", Icons.Filled.AddCircle, Icons.Filled.AddCircle),
    ANALYTICS("Insights", Icons.Filled.BarChart, Icons.Outlined.Analytics),
    PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {

    private val viewModel: CivicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CivicFixApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CivicFixApp(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(CivicNavDestination.FEED) }
    var activeDetailIssueId by remember { mutableStateOf<String?>(null) }
    var showAdminLoginDialog by remember { mutableStateOf(false) }

    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val isLowBandwidth by viewModel.isLowBandwidthMode.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()

    AdminLoginDialog(
        isOpen = showAdminLoginDialog,
        onDismissRequest = { showAdminLoginDialog = false },
        onLoginSuccess = { badgeId, name, dept ->
            viewModel.loginAsAdmin(badgeId, name, dept)
            showAdminLoginDialog = false
        }
    )

    if (activeDetailIssueId != null) {
        DetailScreen(
            issueId = activeDetailIssueId!!,
            viewModel = viewModel,
            onBack = { activeDetailIssueId = null },
            modifier = modifier
        )
        return
    }

    // SEPARATE ADMIN DASHBOARD VIEW: When user is authenticated as Admin, show the dedicated Municipal Admin Dashboard
    if (user.role == UserRole.ADMIN) {
        AdminDashboardScreen(
            viewModel = viewModel,
            onIssueClick = { id -> activeDetailIssueId = id },
            onLogout = { viewModel.logoutToCitizen() },
            modifier = modifier
        )
        return
    }

    // CITIZEN DASHBOARD: Community Reporting & Tracking Interface

    Box(modifier = modifier.fillMaxSize()) {
        LiquidAmbientCanvas()

        Scaffold(
            containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                modifier = Modifier.liquidGlass(
                    shape = GlassTopBarShape,
                    backgroundColor = Color.White.copy(alpha = 0.88f),
                    tintColor = Color(0xFFE0F2FE).copy(alpha = 0.45f),
                    borderColorStart = Color(0xFFCBD5E1),
                    borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                    borderWidth = 1.35.dp,
                    elevation = 4.dp
                ),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Image(
                                    painter = painterResource(id = R.drawable.civicfix_bright_icon),
                                    contentDescription = "CivicFix Logo",
                                    modifier = Modifier
                                        .size(26.dp)
                                        .clip(CircleShape)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CivicFix",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Municipal Citizen Platform",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                actions = {
                    // Low Bandwidth Toggle Indicator with curved glass pill
                    Surface(
                        shape = GlassPillShape,
                        color = if (isLowBandwidth) Color(0xFFFEF3C7) else Color.White.copy(alpha = 0.70f),
                        modifier = Modifier
                            .liquidGlass(
                                shape = GlassPillShape,
                                backgroundColor = if (isLowBandwidth) Color(0xFFFEF3C7) else Color.White.copy(alpha = 0.70f),
                                borderColorStart = if (isLowBandwidth) Color(0xFFD97706) else Color(0xFF94A3B8),
                                borderColorEnd = if (isLowBandwidth) Color(0xFFF59E0B) else Color(0xFFCBD5E1),
                                borderWidth = 1.25.dp,
                                elevation = 1.dp
                            )
                            .clickable { viewModel.toggleLowBandwidthMode() }
                            .padding(end = 4.dp)
                            .semantics {
                                contentDescription = if (isLowBandwidth) "Low-bandwidth mode active" else "Standard network mode"
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.NetworkCheck,
                                contentDescription = null,
                                tint = if (isLowBandwidth) Color(0xFFB45309) else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(14.dp)
                            )
                            if (isLowBandwidth) {
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Lite",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }

                    // Role Switcher Chip with curved glass pill
                    Surface(
                        shape = GlassPillShape,
                        color = Color(0xFFFEF3C7),
                        modifier = Modifier
                            .liquidGlass(
                                shape = GlassPillShape,
                                backgroundColor = Color(0xFFFEF3C7),
                                borderColorStart = Color(0xFFD97706),
                                borderColorEnd = Color(0xFFF59E0B),
                                borderWidth = 1.25.dp,
                                elevation = 1.dp
                            )
                            .clickable { showAdminLoginDialog = true }
                            .padding(end = 4.dp)
                            .testTag("app_bar_role_toggle")
                            .semantics {
                                contentDescription = "Admin login portal"
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Admin Login",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color(0xFFB45309),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }

                    // Notification Bell Icon with Badge
                    IconButton(
                        onClick = { currentTab = CivicNavDestination.PROFILE },
                        modifier = Modifier.testTag("notifications_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadCount > 0) {
                                    Badge(containerColor = MaterialTheme.colorScheme.error) {
                                        Text("$unreadCount")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications, $unreadCount unread",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.liquidGlass(
                    shape = GlassBottomNavShape,
                    backgroundColor = Color.White.copy(alpha = 0.90f),
                    tintColor = Color(0xFFE0F2FE).copy(alpha = 0.40f),
                    borderColorStart = Color(0xFFCBD5E1),
                    borderColorEnd = Color(0xFF0284C7).copy(alpha = 0.45f),
                    borderWidth = 1.35.dp,
                    elevation = 8.dp
                ),
                containerColor = Color.Transparent,
                tonalElevation = 0.dp
            ) {
                CivicNavDestination.entries.forEach { destination ->
                    val isSelected = currentTab == destination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = destination },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) destination.filledIcon else destination.outlinedIcon,
                                contentDescription = destination.label
                            )
                        },
                        label = {
                            Text(
                                text = destination.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)
                        ),
                        modifier = Modifier.testTag("nav_tab_${destination.name.lowercase()}")
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentTab != CivicNavDestination.REPORT) {
                FloatingActionButton(
                    onClick = { currentTab = CivicNavDestination.REPORT },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = GlassPillShape,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .liquidGlass(
                            shape = GlassPillShape,
                            backgroundColor = MaterialTheme.colorScheme.primary,
                            tintColor = Color(0xFF38BDF8),
                            borderWidth = 1.5.dp,
                            borderColorStart = Color.White.copy(alpha = 0.85f),
                            borderColorEnd = Color(0x8038BDF8),
                            elevation = 6.dp
                        )
                        .testTag("report_issue_fab")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Report Issue")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Report Issue", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { target ->
                when (target) {
                    CivicNavDestination.FEED -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onIssueClick = { id -> activeDetailIssueId = id },
                            onOpenAdminLogin = { showAdminLoginDialog = true }
                        )
                    }
                    CivicNavDestination.MAP -> {
                        MapScreen(
                            viewModel = viewModel,
                            onIssueSelected = { id -> activeDetailIssueId = id }
                        )
                    }
                    CivicNavDestination.REPORT -> {
                        ReportScreen(
                            viewModel = viewModel,
                            onReportSubmitted = { newId ->
                                activeDetailIssueId = newId
                                currentTab = CivicNavDestination.FEED
                            }
                        )
                    }
                    CivicNavDestination.ANALYTICS -> {
                        AnalyticsScreen(viewModel = viewModel)
                    }
                    CivicNavDestination.PROFILE -> {
                        ProfileScreen(
                            viewModel = viewModel,
                            onNavigateToIssue = { id -> activeDetailIssueId = id }
                        )
                    }
                }
            }
        }
    }
    }
}

/**
 * Kept for backwards compatibility with baseline instrumented/Robolectric test suites.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme {
        Greeting("CivicFix")
    }
}
